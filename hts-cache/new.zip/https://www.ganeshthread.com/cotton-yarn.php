<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Cotton Yarn</title>
<link rel="shortcut icon" href="images/feviacon.png" />
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="css/animate.css"/>
<link rel="stylesheet" type="text/css" href="css/font-awesome.css"/>
<link rel="stylesheet" type="text/css" href="css/flaticon.css"/>
<link rel="stylesheet" type="text/css" href="css/themify-icons.css"/>
<link rel="stylesheet" type="text/css" href="css/slick.css">
<link rel="stylesheet" type="text/css" href="css/prettyPhoto.css">
<link rel="stylesheet" type="text/css" href="css/shortcodes.css"/>
<link rel="stylesheet" type="text/css" href="css/main.css"/>
<link rel="stylesheet" type="text/css" href="css/megamenu.css"/>
<link rel="stylesheet" type="text/css" href="css/responsive.css"/>
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css"/>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="facebook-domain-verification" content="znjsxsn8b4ry84qap5vw4hp7w2snve" />

<!-- Google tag (gtag.js) --> <script async src="https://www.googletagmanager.com/gtag/js?id=AW-669623619"></script> <script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'AW-669623619'); </script></head>
<body>
<!--page start-->
<div class="page">
  <header id="masthead" class="header ttm-header-style-03">
    
<div class="inspiro-whatsapp-icon">
  <div><a target="_blank" href="https://api.whatsapp.com/send?phone=919904771500&amp;text=I am Interested in Ganesh Jari &amp; Thread"><img src="./images/whatsapp.png"> Let's Connect</a></div>
</div>
<!-- topbar -->
<div class="top_bar ttm-bgcolor-darkgrey clearfix">
  <div class="container">
    <div class="row no-gutters">
      <div class="col-xl-12 d-flex flex-row align-items-center">
        <div class="top_bar_contact_item">
          <div class="top_bar_icon"><i class="ti ti-email"></i></div>
          <a href="mailto:sales@ganeshthread.com">sales@ganeshthread.com</a> </div>
        <div class="top_bar_contact_item">
          <div class="top_bar_icon"><i class="ti ti-file"></i></div>
          <a href="./images/brochure/ganesh-jari-covering-broucher.pdf" target="_blank">Brochure</a>
        </div>
        <div class="top_bar_contact_item">
          <div class="top_bar_icon"><i class="fa fa-inr"></i></div>
          <a href="pay.php">Pay Online</a>
        </div>
        <div class="top_bar_contact_item top_bar_social ml-auto p-0">
          <ul class="social-icons list-inline">
            <li><a class="tooltip-top" href="https://www.facebook.com/ganeshjaricovering" target="_blank" rel="noopener" aria-label="facebook" data-tooltip="Facebook"><i class="fa fa-facebook"></i></a></li>
            <li><a class="tooltip-top" href="https://www.instagram.com/shreeganeshjaricovering/" target="_blank" rel="noopener" aria-label="instagram" data-tooltip="instagram"><i class="fa fa-instagram"></i></a></li>
            <li><a class="tooltip-top" href="https://twitter.com/ShreeJari?s=09" target="_blank" rel="noopener" aria-label="twitter" data-tooltip="twitter"><i class="fa fa-twitter"></i></a></li>
            <li><a class="tooltip-top" href="https://in.pinterest.com/ganeshjari2015/" target="_blank" rel="noopener" aria-label="pinterest" data-tooltip="pinterest"><i class="fa fa-pinterest"></i></a></li>
            <li><a class="tooltip-top" href="https://www.linkedin.com/in/ganesh-jari-thread-87473919b/" target="_blank" rel="noopener" aria-label="linkedin" data-tooltip="linkedin"><i class="fa fa-linkedin"></i></a></li>
            <li><a class="tooltip-top" href="https://www.youtube.com/channel/UCrhCuUlYXh9meL4NEGJbDUQ?view_as=subscriber" target="_blank" rel="noopener" aria-label="youtube" data-tooltip="Youtube"><i class="fa fa-youtube"></i></a></li>
            <li><a class="tooltip-top" href="https://t.me/Ganeshjari14" target="_blank" rel="noopener" aria-label="telegram" data-tooltip="telegram"><i class="fa fa-telegram" aria-hidden="true"></i> </a></li>
            <li><a class="tooltip-top" href="https://www.google.com/maps/place//data=!4m2!3m1!1s0x3be047456bfe347d:0xb9d32c48cedd3813?source=g.page.m" target="_blank" rel="noopener" aria-label="Map and Direction" data-tooltip="Map and Direction"><i class="fa fa-map-marker" aria-hidden="true"></i> </a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- topbar end -->
<!-- site-header-menu -->
<div id="site-header-menu" class="site-header-menu ttm-bgcolor-white">
  <div class="site-header-menu-inner ttm-stickable-header">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <!--site-navigation -->
          <div class="site-navigation d-flex flex-row align-items-center justify-content-between">
            <!-- site-branding -->
            <div class="site-branding "> <a class="home-link" href="index.php" title="Shree Ganesh Jari Covering - All Thred Solution Provider" rel="home"> <img id="logo-img" class="img-fluid auto_size" src="images/logo.png" alt="logo-img"> </a> </div>
            <!-- site-branding end -->
            <div class="d-flex flex-row m-auto">
              <div class="btn-show-menu-mobile menubar menubar--squeeze"> <span class="menubar-box"> <span class="menubar-inner"></span> </span> </div>
              <!-- menu -->
              <nav class="main-menu menu-mobile" id="menu">
                <ul class="menu">
                  <li class="mega-menu-item active"> <a href="index.php">Home</a> </li>
                  <li class="mega-menu-item"> <a href="#" class="mega-menu-link">About</a>
                    <ul class="mega-submenu">
                      <li><a href="company-profile.php">Company Profile</a></li>
                      <li><a href="commitment-achievment.php">Commitment  & Achievment</a></li>
                    </ul>
                  </li>
                  <li class="mega-menu-item"> <a href="#" class="mega-menu-link">Products</a>
                    <ul class="mega-submenu">
                      <li><a href="flora-zari.php">Flora Zari (Jari Kasab)</a></li>
                      <li><a href="polyester-yarn.php">Polyester Yarn </a></li>
                      <li><a href="cotton-yarn.php">Cotton Yarn </a></li>
                      <li><a href="metallic-film.php">Metallic Film </a></li>
                      <li><a href="viscose-yarn.php">Viscose Yarn </a></li>
                      <li><a href="embroidery-thread.php">Embroidery  Thread</a></li>
                    </ul>
                  </li>
                  <li class="mega-menu-item"> <a href="#" class="mega-menu-link">Gallery</a>
                    <ul class="mega-submenu">
                      <li><a href="photo-gallery.php">Photo Gallery</a></li>
                      <li><a href="videos.php">Video</a></li>
                      <li><a href="exhibition.php">Exhibition</a></li>
                    </ul>
                  </li>
                  <!-- <li class="mega-menu-item"><a href="exhibition.php">Exhibition</a></li> -->
                  <li class="mega-menu-item"><a href="blog.php">Blog</a></li>
                  <li class="mega-menu-item"><a href="#" class="mega-menu-link">Dealer</a>
                    <ul class="mega-submenu">
                      <li><a href="dealer-network.php">Dealer Network</a></li>
                      <li><a href="inquiry.php">Dealership Inquiry</a> </li>
                    </ul>
                  </li>
                  <!-- https://docs.google.com/forms/d/1l7_klgSXvWV_t5MKjUQKfswPoY66dn9F3RYIZF8FYMY/edit -->
                  <!-- <li class="mega-menu-item"> <a href="https://docs.google.com/forms/d/e/1FAIpQLSd3IjkrCkFWh9lJ7XRCf77bDSXFGUnQ5vwtuJqVwR2LPdVBLQ/viewform?usp=sf_link" target="_blank">Dealership Inquiry</a> </li> -->
                  <li class="mega-menu-item"> <a href="contact-us.php">Contact</a> </li>
                </ul>
              </nav>
              <!-- menu end -->
            </div>
            <div class="widget_info d-flex flex-row align-items-center">
              <div class="widget_icon ttm-textcolor-skincolor"><i class="flaticon-phone-call"></i></div>
              <div class="widget_content">
                <h3 class="widget_title"><a href="tel:918000971500"> +91 80009 71500 </a></h3>
                <p class="widget_desc">Customer Care</p>
              </div>
            </div>
          </div>
          <!-- site-navigation end-->
        </div>
      </div>
    </div>
  </div>
</div>
<!-- site-header-menu end-->
  </header>
  <!-- Banner -->
  <div class="ttm-page-title-row ttm-bg ttm-bgimage-yes ttm-bgcolor-darkgrey clearfix">
    <div class="ttm-row-wrapper-bg-layer ttm-bg-layer"></div>
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-12">
          <div class="ttm-page-title-row-inner">
            <div class="page-title-heading">
              <h2 class="title">Cotton Yarn </h2>
            </div>
            <div class="breadcrumb-wrapper"> <span> <a title="Homepage" href="#">Products</a> </span> <span>Cotton Yarn </span> </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Banner end-->
  <!--site-main start-->
  <div class="site-main">
    <!--padding_zero-section-->
    <!--padding_zero-section-->
    <section class="ttm-row about-section clearfix">
      <div class="container">
        <!-- row -->
        <div class="row">
          <div class="col-lg-12">
            <div class="ttm-pf-single-content-wrapper ttm-pf-view-left-image">
              <div class="ttm-pf-single-content-wrapper-innerbox">
                <div class="ttm-pf-detail-box">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="row">
                        <div class="col-lg-12 section-title">
                          <div class="title-desc">
                            <h4>Cotton Yarn</h4>
                            <p>Cotton Yarn is naturally soft and lustrous with a high twist finish. The fabric made from Cotton Yarn provides at most comfort to wear. We can use cotton fabrics in all weather conditions. It gives warmth in cold weather and cool in warm weather conditions. 100 % pure Cotton Yarn provides high strength to the fabrics which improves the quality of cotton garments. </p>
                            <p>We provides 100% pure Cotton Yarn by spinning the high quality hygienic cotton. Our Cotton Yarn is widely used by the fabric manufacturers across the world. We supply and export yarns according to the requirement of the global clients as well as the clients around India. Cotton fabric is the choice of all age groups starting from baby to adult. It can be used in all climates and in all trends. We offer both carded and combed yarn in various count required by our clients. We never compromise with our quality standards that vitally lead more revenue to us. Our standard reflects in our quality services and on time delivery. We provide optimum quality cotton yarns for textile industries at the best competitive price.</p>
                            <p>We can supply Cotton Yarns according to the specifications and counts required by our clients. We can accept voluminous orders and provide prompt delivery as we are equipped with good production facility. </p>

                            <p class="font-weight-bold">Currently We Provide Cotton Yarns With The Below Specifications</p>
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">

                                  <tbody>
                                    <tr>
                                      <th scope="row">Variety</th>
                                      <td>Counts</td>
                                    </tr>
                                    <tr>
                                      <th scope="row">Housiery carded</th>
                                      <td>10s to 40s Ne</td>
                                    </tr>
                                    <tr>
                                      <th scope="row">Combed</th>
                                      <td>16s to 60s Ne</td>
                                    </tr>
                                    <tr>
                                      <th scope="row">Weaving carded</th>
                                      <td>10s to 40s Ne</td>
                                    </tr>
                                    <tr>
                                      <th scope="row">Combed</th>
                                      <td>16s to 100s Ne</td>
                                    </tr>
                                    <tr>
                                      <th scope="row">Open End</th>
                                      <td>2s to 30s Ne</td>
                                    </tr>
                                  </tbody>
                                </table>
                                <!-- <img src="./images/products/cotton-yarn/table.jpg" class="img-fluid"> -->
                            </div>
                           <!--  <div> <b>Features</b>
                              <ul class="ttm-list ttm-list-style-icon ttm-list-icon-color-skincolor margin_top15">
                                <li><i class="ti ti-check"></i>
                                  <div class="ttm-list-li-content">Wide Colour Range </div>
                                </li>
                                <li><i class="ti ti-check"></i>
                                  <div class="ttm-list-li-content">Perfect Lenght </div>
                                </li>
                                <li><i class="ti ti-check"></i>
                                  <div class="ttm-list-li-content">Organza Grade </div>
                                </li>
                                <li><i class="ti ti-check"></i>
                                  <div class="ttm-list-li-content">Export Packing </div>
                                </li>
                                <li><i class="ti ti-check"></i>
                                  <div class="ttm-list-li-content">Nuetral Packing </div>
                                </li>
                                <li><i class="ti ti-check"></i>
                                  <div class="ttm-list-li-content">Branding Packing </div>
                                </li>
                              </ul>
                            </div> -->
                          </div>
                        </div>

                        <div class="col-lg-12 section-title pt-5">
                          <div class="title-desc">
                            <h4>Type of Cotton Yarn</h4>
                            <p>It’s important to know the different kinds of cotton fibers you can find on the shelf at your local yarn shop. There is:</p>

                            <h5 class="pt-md-3">Egyptian & Sea Island Cotton Yarn</h5>
                            <p>Egyptian and Sea Island cotton yarns are considered to be the finest cotton fibers. These kinds of cotton are very soft and are resistant to fraying and pilling. Drops' Safran yarn is a great Egyptian Cotton option.</p>
                            
                            
                            <h5 class="pt-md-3">Pima Cotton Yarn</h5>
                            <p>Pima cotton yarn is extremely similar to Egyptian cotton but is primarily grown in the United States. (Fun Fact: The name “Pima” comes from the Pima American Indians of Arizona as they helped USDA scientists experiment with breeding Egyptian cotton in the early 1900s.) Cascade Yarn has some gorgeous Pima Cotton if you're interested!</p>

                            
                            <h5 class="pt-md-3">Organic Cotton Yarn</h5>
                            <p>Organic cotton fibers are grown without pesticides or synthetic fertilizers. This is a good option if you’re looking to be more sustainable and support farming that produces less pollution. Gazzal has some really nice Organic Baby Cotton that is pretty affordable!</p>

                            
                            <h5 class="pt-md-3">Recycled Cotton Yarn</h5>
                            <p>Recycled cotton yarn is made from recycled fabric. This is a great sustainable option! Cotton takes a lot of water to produce. However, recycled cotton yarn uses less water and gives life to fabric that might otherwise be in a landfill. Stitch & Story’s Eco Cotton Yarn is made from 95% recycled cotton!</p>

                            
                            <h5 class="pt-md-3">Mercerized Cotton Yarn</h5>
                            <p>Mercerized cotton isn’t a type of fiber, but a treatment that is done to the cotton fibers. The treatment involves submerging cotton in a soda solution that results in a more strong fiber that is more receptive to dye. The end result is a yarn that is almost silk-like and has vibrant colors. Also, because mercerization causes the fibers to be condensed even closer to one another, the fabric you make with it will actually be even cooler and airier compared to non-mercerized cotton. 24/7 Cotton by Lion Brand is a popular and affordable cotton yarn, and it is mercerized!</p>


                            <h5 class="pt-md-3">Mercerized Cotton Yarn</h5>
                            <p>Mercerized cotton isn’t a type of fiber, but a treatment that is done to the cotton fibers. The treatment involves submerging cotton in a soda solution that results in a more strong fiber that is more receptive to dye. The end result is a yarn that is almost silk-like and has vibrant colors. Also, because mercerization causes the fibers to be condensed even closer to one another, the fabric you make with it will actually be even cooler and airier compared to non-mercerized cotton. 24/7 Cotton by Lion Brand is a popular and affordable cotton yarn, and it is mercerized!</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                
              


                <div class="ttm-pf-single-content-area">
                  <div class="row ttm-pf-single-related-wrapper mb_15">
                    <div class="col-lg-3 col-md-4 col-sm-6">
                      <!--featured-icon-box-->
                      <div class="featured-imagebox featured-imagebox-portfolio style2">
                        <!-- ttm-box-view-overlay -->
                        <div class="ttm-box-view-overlay ttm-portfolio-box-view-overlay">
                          <!-- featured-thumbnail -->
                          <div class="featured-thumbnail"> <a href="#"> <img class="img-fluid" src="./images/products/cotton-yarn/0.jpg" alt="image" height="100%" width="100%"> </a> </div>
                          <!-- featured-thumbnail end-->
                          <div class="ttm-media-link"> <a class="ttm_prettyphoto ttm_image" href="./images/products/cotton-yarn/0.jpg" data-rel="prettyPhoto" tabindex="0"> <i class="fa fa-search"></i> </a> </div>
                        </div>
                        <!-- <div class="featured-content">
                          <div class="featured-title">
                            <h3>110D Polyester Lichi Yarn</h3>
                          </div>
                        </div> -->
                      </div>
                      <!-- featured-icon-box end-->
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6">
                      <div class="featured-imagebox featured-imagebox-portfolio style2">
                        <div class="ttm-box-view-overlay ttm-portfolio-box-view-overlay">
                          <div class="featured-thumbnail"> <a href="#"> <img class="img-fluid" src="./images/products/cotton-yarn/1.jpg" alt="image" height="100%" width="100%"> </a> </div>
                          <div class="ttm-media-link"> <a class="ttm_prettyphoto ttm_image" href="./images/products/cotton-yarn/1.jpg" data-rel="prettyPhoto" tabindex="0"> <i class="fa fa-search"></i> </a> </div>
                        </div>
                      </div>
                    </div>

                    <div class="col-lg-3 col-md-4 col-sm-6">
                      <div class="featured-imagebox featured-imagebox-portfolio style2">
                        <div class="ttm-box-view-overlay ttm-portfolio-box-view-overlay">
                          <div class="featured-thumbnail"> <a href="#"> <img class="img-fluid" src="./images/products/cotton-yarn/2.jpg" alt="image" height="100%" width="100%"> </a> </div>
                          <div class="ttm-media-link"> <a class="ttm_prettyphoto ttm_image" href="./images/products/cotton-yarn/2.jpg" data-rel="prettyPhoto" tabindex="0"> <i class="fa fa-search"></i> </a> </div>
                        </div>
                      </div>
                    </div>

                    <div class="col-lg-3 col-md-4 col-sm-6">
                      <div class="featured-imagebox featured-imagebox-portfolio style2">
                        <div class="ttm-box-view-overlay ttm-portfolio-box-view-overlay">
                          <div class="featured-thumbnail"> <a href="#"> <img class="img-fluid" src="./images/products/cotton-yarn/3.jpg" alt="image" height="100%" width="100%"> </a> </div>
                          <div class="ttm-media-link"> <a class="ttm_prettyphoto ttm_image" href="./images/products/cotton-yarn/3.jpg" data-rel="prettyPhoto" tabindex="0"> <i class="fa fa-search"></i> </a> </div>
                        </div>
                      </div>
                    </div>

                    <div class="col-lg-3 col-md-4 col-sm-6">
                      <div class="featured-imagebox featured-imagebox-portfolio style2">
                        <div class="ttm-box-view-overlay ttm-portfolio-box-view-overlay">
                          <div class="featured-thumbnail"> <a href="#"> <img class="img-fluid" src="./images/products/cotton-yarn/4.jpg" alt="image" height="100%" width="100%"> </a> </div>
                          <div class="ttm-media-link"> <a class="ttm_prettyphoto ttm_image" href="./images/products/cotton-yarn/4.jpg" data-rel="prettyPhoto" tabindex="0"> <i class="fa fa-search"></i> </a> </div>
                        </div>
                      </div>
                    </div>

                    <div class="col-lg-3 col-md-4 col-sm-6">
                      <div class="featured-imagebox featured-imagebox-portfolio style2">
                        <div class="ttm-box-view-overlay ttm-portfolio-box-view-overlay">
                          <div class="featured-thumbnail"> <a href="#"> <img class="img-fluid" src="./images/products/cotton-yarn/5.jpg" alt="image" height="100%" width="100%"> </a> </div>
                          <div class="ttm-media-link"> <a class="ttm_prettyphoto ttm_image" href="./images/products/cotton-yarn/5.jpg" data-rel="prettyPhoto" tabindex="0"> <i class="fa fa-search"></i> </a> </div>
                        </div>
                      </div>
                    </div>

                    <div class="col-lg-3 col-md-4 col-sm-6">
                      <div class="featured-imagebox featured-imagebox-portfolio style2">
                        <div class="ttm-box-view-overlay ttm-portfolio-box-view-overlay">
                          <div class="featured-thumbnail"> <a href="#"> <img class="img-fluid" src="./images/products/cotton-yarn/6.jpg" alt="image" height="100%" width="100%"> </a> </div>
                          <div class="ttm-media-link"> <a class="ttm_prettyphoto ttm_image" href="./images/products/cotton-yarn/6.jpg" data-rel="prettyPhoto" tabindex="0"> <i class="fa fa-search"></i> </a> </div>
                        </div>
                      </div>
                    </div>

                    <div class="col-lg-3 col-md-4 col-sm-6">
                      <div class="featured-imagebox featured-imagebox-portfolio style2">
                        <div class="ttm-box-view-overlay ttm-portfolio-box-view-overlay">
                          <div class="featured-thumbnail"> <a href="#"> <img class="img-fluid" src="./images/products/cotton-yarn/7.jpg" alt="image" height="100%" width="100%"> </a> </div>
                          <div class="ttm-media-link"> <a class="ttm_prettyphoto ttm_image" href="./images/products/cotton-yarn/7.jpg" data-rel="prettyPhoto" tabindex="0"> <i class="fa fa-search"></i> </a> </div>
                        </div>
                      </div>
                    </div>

                  </div>
                </div>
              </div>
              <!-- row end-->
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--fid-section end-->
    <!--padding_zero-section-->
    <!--blog-section end-->
  </div>
  <!--site-main end-->
  <!--footer start-->
  <footer class="footer widget-footer ttm-bgcolor-darkgrey ttm-textcolor-white clearfix">
    <div class="second-footer">
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3 widget-area wow fadeInUp animated">
        <div class="widget widget-latest-tweets clearfix">
          <h6 class="">Shree Ganesh Jari Covering Pvt. Ltd.</h6>
          <ul class="widget_contact_wrapper">
            <li><i class="ttm-textcolor-skincolor fa fa-map-marker"></i> <b>Office</b><br/>3013, Central Bazar,<br/>
             Opp. Varachha Police Station,<br/>
              Varachha Main Road,<br/>
              Surat-395006,<br/>
              Gujarat, India </li>
            <li><i class="ttm-textcolor-skincolor fa fa-map-marker"></i> <b>Factory</b><br/>Block No 225, Plot No: 2 to 5,<br/>
             Shree Krishna Industrial Estate,<br/>
              Mota Borsara, Nr.Darbar Hotel,<br/>
              Kim, Surat-394110,<br/>
              Gujarat, India </li>
          </ul>
        </div>
      </div>
      <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3 offset-md-1 widget-area wow fadeInUp animated">
        <div class="widget widget-latest-tweets clearfix">
          <h6 class="">Contact Us</h6>
          <ul class="widget_contact_wrapper">
            <li><i class="ttm-textcolor-skincolor fa fa-phone"></i><a href="tel:918000971500"> +91 80009 71500</a></li>
            <li><i class="ttm-textcolor-skincolor fa fa-whatsapp"></i><a href="tel:919016025691"> +91 99047 71500</a></li>
            <li><i class="ttm-textcolor-skincolor fa fa-envelope-o"></i><a href="mailto:sales@ganeshthread.com"> sales@ganeshthread.com</a></li>
            <!--li><i class="ttm-textcolor-skincolor fa fa fa-map-marker"></i><a href="https://g.page/ganesh-jari-thread?gm" target="_blank">Map & Direction</a></li-->
          </ul>
        </div>
      </div>      
      <div class="col-xs-12  col-sm-6 col-md-6 col-lg-2 widget-area wow fadeInUp animated">
        <div class="widget widget_nav_menu clearfix">
          <h6 class="">Quick Links</h6>
          <ul id="menu-footer-quick-links" class="menu">
            <li><a href="index.php">Home</a></li>
            <li><a href="company-profile.php">About</a></li>
            <li><a href="dealer-network.php"> Dealer Network</a></li>
            <li><a href="photo-gallery.php">Gallery</a></li>
            <li><a href="inquiry.php">Dealership Inquiry</a></li>
            <li><a href="pay.php">Pay Online</a></li>
			<li><a href="contact-us.php">Contact Us</a></li>
            <li><a href="blog.php">Blog</a></li>
          </ul>
        </div>
      </div>
      <div class="col-xs-12 col-sm-6 col-md-6 col-lg-2 widget-area wow fadeInUp animated">
        <div class="widget widget_nav_menu clearfix">
          <h6 class="">Our Products</h6>
          <ul id="menu-footer-quick-links" class="menu">
            <li><a href="flora-zari.php">Flora Zari (Jari Kasab)</a></li>
            <li><a href="polyester-yarn.php">Polyester Yarn </a></li>
            <li><a href="cotton-yarn.php">Cotton Yarn </a></li>
            <li><a href="metallic-film.php">Metallic Film </a></li>
            <li><a href="viscose-yarn.php">Viscose Yarn </a></li>
            <li><a href="embroidery-thread.php">Embroidery  Thread</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="bottom-footer-text copyright">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 text-center">
        <div class="widget widget_social clearfix">
          <div class="social-icons">
            <ul class="social-icons list-inline">
              <li><a class="tooltip-top" href="https://www.facebook.com/ganeshjaricovering" target="_blank" rel="noopener" aria-label="facebook" data-tooltip="Facebook"><i class="fa fa-facebook"></i></a></li>
              <li><a class="tooltip-top" href="https://www.instagram.com/shreeganeshjaricovering/" target="_blank" rel="noopener" aria-label="instagram" data-tooltip="Instagram"><i class="fa fa-instagram"></i></a></li>
              <li><a class="tooltip-top" href="https://twitter.com/ShreeJari?s=09" target="_blank" rel="noopener" aria-label="twitter" data-tooltip="Twitter"><i class="fa fa-twitter"></i></a></li>
              <li><a class="tooltip-top" href="https://in.pinterest.com/ganeshjari2015/" target="_blank" rel="noopener" aria-label="pinterest" data-tooltip="Pinterest"><i class="fa fa-pinterest"></i></a></li>
              <li><a class="tooltip-top" href="https://www.linkedin.com/in/ganesh-jari-thread-87473919b/" target="_blank" rel="noopener" aria-label="linkedin" data-tooltip="Linkedin"><i class="fa fa-linkedin"></i></a></li>
              <li><a class="tooltip-top" href="https://www.youtube.com/channel/UCrhCuUlYXh9meL4NEGJbDUQ?view_as=subscriber" target="_blank" rel="noopener" aria-label="youtube" data-tooltip="Youtube"><i class="fa fa-youtube"></i></a></li>
              <li><a class="tooltip-top" href="https://t.me/Ganeshjari14" target="_blank" rel="noopener" aria-label="telegram" data-tooltip="Telegram"><i class="fa fa-telegram" aria-hidden="true"></i> </a></li>
              <li><a class="tooltip-top" href="https://www.google.com/maps/place//data=!4m2!3m1!1s0x3be047456bfe347d:0xb9d32c48cedd3813?source=g.page.m" target="_blank" rel="noopener" aria-label="Map and Direction" data-tooltip="Map and Direction"><i class="fa fa-map-marker" aria-hidden="true"></i> </a></li>
            </ul>
          </div>
        </div>
        <br/>
        <div class="text-center"> <span class="cpy-text">Copyright &copy; 2021 <a href="#" class="ttm-textcolor-skincolor font-weight-500">Shree Ganesh Jari Covering</a> All rights reserved.</span> </div>
      </div>
    </div>
  </div>
</div>
  </footer>
  <!--footer end-->
  <!--back-to-top start-->
  <a id="totop" href="#top"> <i class="fa fa-angle-up"></i> </a>
  <!--back-to-top end-->
</div>
<!-- page end -->
<!-- Javascript -->
<script src="./js/jquery.js"></script>
<script src="./js/popper.min.js"></script>
<script src="./js/wow.js"></script>
<!-- main-js -->
<script src="./js/script.js"></script>
<script src="./js/popper.min.js"></script>
<script src="./js/bootstrap.min.js"></script>
<script src="./js/appear.js"></script>
<script src="js/jquery-3.6.0.min.js"></script>
<script src="js/jquery-migrate-3.3.2.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.easing.js"></script>
<script src="./js/scrollbar.js"></script>
<script src="js/jquery-waypoints.js"></script>
<script src="js/jquery-validate.js"></script>
<script src="js/jquery.prettyPhoto.js"></script>
<script src="js/slick.min.js"></script>
<script src="js/numinate.min.js"></script>
<script src="js/imagesloaded.min.js"></script>
<script src="js/jquery-isotope.js"></script>
<script src="js/main.js"></script><!-- Javascript end-->
</body>
</html>
