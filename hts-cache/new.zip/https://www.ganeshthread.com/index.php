<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Shree Ganesh Jari Covering - All Thred Solution Provider</title>
<link rel="shortcut icon" href="images/feviacon.png" />
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="css/animate.css"/>
<link rel="stylesheet" type="text/css" href="css/font-awesome.css"/>
<link rel="stylesheet" type="text/css" href="css/flaticon.css"/>
<link rel="stylesheet" type="text/css" href="css/themify-icons.css"/>
<link rel="stylesheet" type="text/css" href="css/slick.css">
<link rel="stylesheet" type="text/css" href="css/prettyPhoto.css">
<link rel="stylesheet" type="text/css" href="css/shortcodes.css"/>
<link rel="stylesheet" type="text/css" href="css/main.css"/>
<link rel="stylesheet" type="text/css" href="css/megamenu.css"/>
<link rel="stylesheet" type="text/css" href="css/responsive.css"/>
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css"/>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="facebook-domain-verification" content="znjsxsn8b4ry84qap5vw4hp7w2snve" />

<!-- Google tag (gtag.js) --> <script async src="https://www.googletagmanager.com/gtag/js?id=AW-669623619"></script> <script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'AW-669623619'); </script></head>
<body>
<!--page start-->
<div class="page">
<header id="masthead" class="header ttm-header-style-03">

<div class="inspiro-whatsapp-icon">
  <div><a target="_blank" href="https://api.whatsapp.com/send?phone=919904771500&amp;text=I am Interested in Ganesh Jari &amp; Thread"><img src="./images/whatsapp.png"> Let's Connect</a></div>
</div>
<!-- topbar -->
<div class="top_bar ttm-bgcolor-darkgrey clearfix">
  <div class="container">
    <div class="row no-gutters">
      <div class="col-xl-12 d-flex flex-row align-items-center">
        <div class="top_bar_contact_item">
          <div class="top_bar_icon"><i class="ti ti-email"></i></div>
          <a href="mailto:sales@ganeshthread.com">sales@ganeshthread.com</a> </div>
        <div class="top_bar_contact_item">
          <div class="top_bar_icon"><i class="ti ti-file"></i></div>
          <a href="./images/brochure/ganesh-jari-covering-broucher.pdf" target="_blank">Brochure</a>
        </div>
        <div class="top_bar_contact_item">
          <div class="top_bar_icon"><i class="fa fa-inr"></i></div>
          <a href="pay.php">Pay Online</a>
        </div>
        <div class="top_bar_contact_item top_bar_social ml-auto p-0">
          <ul class="social-icons list-inline">
            <li><a class="tooltip-top" href="https://www.facebook.com/ganeshjaricovering" target="_blank" rel="noopener" aria-label="facebook" data-tooltip="Facebook"><i class="fa fa-facebook"></i></a></li>
            <li><a class="tooltip-top" href="https://www.instagram.com/shreeganeshjaricovering/" target="_blank" rel="noopener" aria-label="instagram" data-tooltip="instagram"><i class="fa fa-instagram"></i></a></li>
            <li><a class="tooltip-top" href="https://twitter.com/ShreeJari?s=09" target="_blank" rel="noopener" aria-label="twitter" data-tooltip="twitter"><i class="fa fa-twitter"></i></a></li>
            <li><a class="tooltip-top" href="https://in.pinterest.com/ganeshjari2015/" target="_blank" rel="noopener" aria-label="pinterest" data-tooltip="pinterest"><i class="fa fa-pinterest"></i></a></li>
            <li><a class="tooltip-top" href="https://www.linkedin.com/in/ganesh-jari-thread-87473919b/" target="_blank" rel="noopener" aria-label="linkedin" data-tooltip="linkedin"><i class="fa fa-linkedin"></i></a></li>
            <li><a class="tooltip-top" href="https://www.youtube.com/channel/UCrhCuUlYXh9meL4NEGJbDUQ?view_as=subscriber" target="_blank" rel="noopener" aria-label="youtube" data-tooltip="Youtube"><i class="fa fa-youtube"></i></a></li>
            <li><a class="tooltip-top" href="https://t.me/Ganeshjari14" target="_blank" rel="noopener" aria-label="telegram" data-tooltip="telegram"><i class="fa fa-telegram" aria-hidden="true"></i> </a></li>
            <li><a class="tooltip-top" href="https://www.google.com/maps/place//data=!4m2!3m1!1s0x3be047456bfe347d:0xb9d32c48cedd3813?source=g.page.m" target="_blank" rel="noopener" aria-label="Map and Direction" data-tooltip="Map and Direction"><i class="fa fa-map-marker" aria-hidden="true"></i> </a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- topbar end -->
<!-- site-header-menu -->
<div id="site-header-menu" class="site-header-menu ttm-bgcolor-white">
  <div class="site-header-menu-inner ttm-stickable-header">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <!--site-navigation -->
          <div class="site-navigation d-flex flex-row align-items-center justify-content-between">
            <!-- site-branding -->
            <div class="site-branding "> <a class="home-link" href="index.php" title="Shree Ganesh Jari Covering - All Thred Solution Provider" rel="home"> <img id="logo-img" class="img-fluid auto_size" src="images/logo.png" alt="logo-img"> </a> </div>
            <!-- site-branding end -->
            <div class="d-flex flex-row m-auto">
              <div class="btn-show-menu-mobile menubar menubar--squeeze"> <span class="menubar-box"> <span class="menubar-inner"></span> </span> </div>
              <!-- menu -->
              <nav class="main-menu menu-mobile" id="menu">
                <ul class="menu">
                  <li class="mega-menu-item active"> <a href="index.php">Home</a> </li>
                  <li class="mega-menu-item"> <a href="#" class="mega-menu-link">About</a>
                    <ul class="mega-submenu">
                      <li><a href="company-profile.php">Company Profile</a></li>
                      <li><a href="commitment-achievment.php">Commitment  & Achievment</a></li>
                    </ul>
                  </li>
                  <li class="mega-menu-item"> <a href="#" class="mega-menu-link">Products</a>
                    <ul class="mega-submenu">
                      <li><a href="flora-zari.php">Flora Zari (Jari Kasab)</a></li>
                      <li><a href="polyester-yarn.php">Polyester Yarn </a></li>
                      <li><a href="cotton-yarn.php">Cotton Yarn </a></li>
                      <li><a href="metallic-film.php">Metallic Film </a></li>
                      <li><a href="viscose-yarn.php">Viscose Yarn </a></li>
                      <li><a href="embroidery-thread.php">Embroidery  Thread</a></li>
                    </ul>
                  </li>
                  <li class="mega-menu-item"> <a href="#" class="mega-menu-link">Gallery</a>
                    <ul class="mega-submenu">
                      <li><a href="photo-gallery.php">Photo Gallery</a></li>
                      <li><a href="videos.php">Video</a></li>
                      <li><a href="exhibition.php">Exhibition</a></li>
                    </ul>
                  </li>
                  <!-- <li class="mega-menu-item"><a href="exhibition.php">Exhibition</a></li> -->
                  <li class="mega-menu-item"><a href="blog.php">Blog</a></li>
                  <li class="mega-menu-item"><a href="#" class="mega-menu-link">Dealer</a>
                    <ul class="mega-submenu">
                      <li><a href="dealer-network.php">Dealer Network</a></li>
                      <li><a href="inquiry.php">Dealership Inquiry</a> </li>
                    </ul>
                  </li>
                  <!-- https://docs.google.com/forms/d/1l7_klgSXvWV_t5MKjUQKfswPoY66dn9F3RYIZF8FYMY/edit -->
                  <!-- <li class="mega-menu-item"> <a href="https://docs.google.com/forms/d/e/1FAIpQLSd3IjkrCkFWh9lJ7XRCf77bDSXFGUnQ5vwtuJqVwR2LPdVBLQ/viewform?usp=sf_link" target="_blank">Dealership Inquiry</a> </li> -->
                  <li class="mega-menu-item"> <a href="contact-us.php">Contact</a> </li>
                </ul>
              </nav>
              <!-- menu end -->
            </div>
            <div class="widget_info d-flex flex-row align-items-center">
              <div class="widget_icon ttm-textcolor-skincolor"><i class="flaticon-phone-call"></i></div>
              <div class="widget_content">
                <h3 class="widget_title"><a href="tel:918000971500"> +91 80009 71500 </a></h3>
                <p class="widget_desc">Customer Care</p>
              </div>
            </div>
          </div>
          <!-- site-navigation end-->
        </div>
      </div>
    </div>
  </div>
</div>
<!-- site-header-menu end-->
</header>
  <!-- Banner -->
 <div class="banner_slider_wrapper">
 <div class="banner_slider banner_slider_2">
      <div class="slide">
        <div class="slide_img" style="background-image: url(images/banner/slider-1.jpg);"></div>
        <div class="slide__content--headings ttm-textcolor-white text-center">
          <h3 data-animation="fadeInDown" class="">Since 2008</h3>
          <h2 data-animation="fadeInDown" class="">Prominent Manufacturer of<br/><strong> Kasab Jari and Yarn</strong></h2>
          <p data-animation="fadeInDown" class="">Wide range of Kasab Jari, Yarn and Metalic Films under one roof</p>
          <div class="d-inline-block margin_top30 res-767-margin_top20" data-animation="fadeInUp" data-delay="1.4"> <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-square ttm-btn-style-fill ttm-btn-color-skincolor margin_right15" href="#" tabindex="0">more details</a> <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-square ttm-btn-style-border ttm-btn-color-white" href="#" tabindex="0">get a quote</a> </div>
        </div>
      </div>
	  
	  <div class="slide">
        <div class="slide_img" style="background-image: url(images/banner/slider-2.jpg);"></div>
        <div class="slide__content--headings ttm-textcolor-white text-center">
          <h3 data-animation="fadeInDown" class="">Since 2008</h3>
          <h2 data-animation="fadeInDown" class="">One Group <br/>All  <strong> Thread Solution</strong></h2>
          <p data-animation="fadeInDown" class="">Ganesh Group is one stop destination for all thread solution</p>
          <div class="d-inline-block margin_top30 res-767-margin_top20" data-animation="fadeInUp" data-delay="1.4"> <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-square ttm-btn-style-fill ttm-btn-color-skincolor margin_right15" href="#" tabindex="0">more details</a> <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-square ttm-btn-style-border ttm-btn-color-white" href="#" tabindex="0">get a quote</a> </div>
        </div>
      </div>
      <div class="slide">
        <div class="slide_img" style="background-image: url(images/banner/slider-3.jpg);"></div>
        <div class="slide__content--headings ttm-textcolor-white text-center">
          <h3 data-animation="fadeInDown" class="">Since 2008</h3>
          <h2 data-animation="fadeInDown" class="">"Perfect Length is <br/> <strong>Our Motto"</strong></h2>
          <p data-animation="fadeInDown" class="">We believe in offering perfect quality & quantity</p>
          <div class="d-inline-block margin_top30 res-767-margin_top20" data-animation="fadeInUp" data-delay="1.4"> <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-square ttm-btn-style-fill ttm-btn-color-skincolor margin_right15" href="#" tabindex="0">more details</a> <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-square ttm-btn-style-border ttm-btn-color-white" href="#" tabindex="0">get a quote</a> </div>
        </div>
      </div>
      <div class="slide">
        <div class="slide_img" style="background-image: url(images/banner/slider-4.jpg);"></div>
        <div class="slide__content--headings ttm-textcolor-white text-center">
          <h3 data-animation="fadeInDown" class="">Since 2008</h3>
          <h2 data-animation="fadeInDown" class="">Local Manufacturing<br/><strong>Global Footprints</strong></h2>
          <p data-animation="fadeInDown" class="">Ganesh Group is present in 8 States of India and 2 Countries</p>
          <div class="d-inline-block margin_top30 res-767-margin_top20" data-animation="fadeInUp" data-delay="1.4"> <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-square ttm-btn-style-fill ttm-btn-color-skincolor margin_right15" href="#" tabindex="0">more details</a> <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-square ttm-btn-style-border ttm-btn-color-white" href="#" tabindex="0">get a quote</a> </div>
        </div>
      </div>
    </div> 
 </div>
  <!-- Banner end-->
  <!--site-main start-->
  <div class="site-main">
    <!--padding_zero-section-->
    <!--padding_zero-section-->
    <section class="ttm-row about-section clearfix">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 col-md-8 col-sm-8 wow fadeInUp animated">
            <div class="ttm_single_image-wrapper"> <img class="img-fluid auto_size" width="569" height="655" src="images/single-img-03.png" alt="single-03"> </div>
          </div>
          <div class="col-lg-6 col-md-12 col-xs-12 wow fadeInUp animated">
            <div class="margin_top40">
              <!-- section title -->
              <div class="section-title">
                <div class="title-header">
                  <h3>Ganesh jari & yarn

</h3>
                  <h2 class="title">A Trusted Name in Textile Industry <b>Since 2008</b></h2>
                </div>
                <div class="title-desc">
                  <p><b>Ganesh Group of Companies</b> is a leading manufacturer of  Flora Zari (30D,70D,100D) , Polyester Jari (150D,180D), Nylon Jari (110D),Half Fine Zari, Imitation Zari, Embroidery Thread, Metallic Film, Mettalic Rolls, Mx Jari, Polyester Yarn and Viscose Yarn.</b> Established in 2008, we have achieved several milestones.  Ganesh Jari and Thread is known to provide its superior quality products and utmost customer satisfaction service. </p>
                  <p>With our presence in 8 States of India and 2 Countries, today we are actively working with 350 dealers and proudly serving more than 1500 customers. We are fully equipped to fulfill Quality, Quantity and On Time delivery. <b>We have capacity of manufacturing 200 Ton Flora Zari and 100 Ton Polyester yarn per month.</b> </p>
                  <p>"Perfect Length" is the Moto of our company and we go the extra mile to achieve this. We work to transform the world of Textile Industry with Technology and to become a globally recognized name.</p>
                 
                </div>
              </div>
              <!-- section title end -->
              <div class="margin_top35 res-767-margin_top20"> <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-square ttm-btn-style-border ttm-btn-color-dark  margin_top15" href="company-profile.php">View More</a> </div>
            </div>
          </div>
        </div>
        <!-- row end -->
      </div>
    </section>
    <section class="ttm-row fid-section ttm-bgimage-yes bg-img1 ttm-bg ttm-bgcolor-darkgrey clearfix">
      <div class="ttm-row-wrapper-bg-layer ttm-bg-layer"></div>
      <div class="container">
        <!-- row -->
        <div class="row">
          <div class="col-lg-8 m-auto">
            <!-- section title -->
            <div class="section-title title-style-center_text">
              <div class="title-header">
                <h2 class="title">Some Interesting Facts <b class="ttm-textcolor-skincolor"> About Us</b></h2>
              </div>
            </div>
            <!-- section title end -->
          </div>
        </div>
        <div class="row">
          <div class="col-lg-3 col-md-6 col-sm-6 wow fadeInUp animated">
            <!-- ttm-fid -->
            <div class="ttm-fid inside ttm-fid-with-icon style1">
              <div class="ttm-fid-icon-wrapper"> <i class="flaticon flaticon-yarn-1"></i> </div>
              <div class="ttm-fid-contents">
                <h4 class="ttm-fid-inner"> <span   data-appear-animation="animateDigits" 
                                                data-from="0" 
                                                data-to="125" 
                                                data-interval="15" 
                                                data-before="" 
                                                data-before-style="sup" 
                                                data-after=""
                                                data-after-style="sub" 
                                                class="numinate">125</span> </h4>
                <h3 class="ttm-fid-title">Zari Shade Range</h3>
              </div>
            </div>
            <!-- ttm-fid end -->
          </div>
          <div class="col-lg-3 col-md-6 col-sm-6 wow fadeInUp animated">
            <!-- ttm-fid -->
            <div class="ttm-fid inside ttm-fid-with-icon style1">
              <div class="ttm-fid-icon-wrapper"> <i class="flaticon flaticon-wool"></i> </div>
              <div class="ttm-fid-contents">
                <h4 class="ttm-fid-inner"> <span   data-appear-animation="animateDigits" 
                                                data-from="0" 
                                                data-to="350" 
                                                data-interval="15" 
                                                data-before="" 
                                                data-before-style="sup" 
                                                data-after="" 
                                                data-after-style="span" 
                                                class="numinate">350 </span> </h4>
                <h3 class="ttm-fid-title">Polyester Shade Range </h3>
              </div>
            </div>
            <!-- ttm-fid end -->
          </div>
          <div class="col-lg-3 col-md-6 col-sm-6 wow fadeInUp animated">
            <!-- ttm-fid -->
            <div class="ttm-fid inside ttm-fid-with-icon style1">
              <div class="ttm-fid-icon-wrapper"> <i class="flaticon flaticon-wool-1"></i> </div>
              <div class="ttm-fid-contents">
                <h4 class="ttm-fid-inner"> <span   data-appear-animation="animateDigits" 
                                                data-from="0" 
                                                data-to="400" 
                                                data-interval="15" 
                                                data-before="" 
                                                data-before-style="sup" 
                                                data-after="" 
                                                data-after-style="span" 
                                                class="numinate">400 </span> </h4>
                <h3 class="ttm-fid-title">Zarman Shade Range </h3>
              </div>
            </div>
            <!-- ttm-fid end -->
          </div>
          <div class="col-lg-3 col-md-6 col-sm-6 wow fadeInUp animated">
            <!-- ttm-fid -->
            <div class="ttm-fid inside ttm-fid-with-icon style1">
              <div class="ttm-fid-icon-wrapper"> <i class="flaticon flaticon-knitting"></i> </div>
              <div class="ttm-fid-contents">
                <h4 class="ttm-fid-inner"> <span   data-appear-animation="animateDigits" 
                                                data-from="0" 
                                                data-to="600" 
                                                data-interval="15" 
                                                data-before="" 
                                                data-before-style="sup" 
                                                data-after="" 
                                                data-after-style="span" 
                                                class="numinate">600 </span> </h4>
                <h3 class="ttm-fid-title">Viscoss Shade Range </h3>
              </div>
            </div>
            <!-- ttm-fid end -->
          </div>
        </div>
        <!-- row end -->
        <div class="row">
          <div class="col-lg-12">
            <div class="margin_top35 mb_15 text-center"> </div>
            <div class="padding_bottom90 res-991-padding_bottom0"></div>
          </div>
        </div>
      </div>
    </section>
    <!--fid-section end-->
    <!--padding_zero-section-->
    <section class="ttm-row padding_zero-section clearfix">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="ttm-bg ttm-col-bgcolor-yes ttm-bg ttm-col-bgimage-yes col-bg-img-one ttm-left-span spacing-2">
              <div class="ttm-col-wrapper-bg-layer ttm-bg-layer">
                <div class="ttm-col-wrapper-bg-layer-inner"></div>
              </div>
              <div class="layer-content">
                <!-- section title -->
                <div class="section-title style2">
                  <div class="title-header">
                    <h3>OUR PRODUCTS </h3>
                    <h2 class="title">Superior Quality at <b>No Extra Cost!</b> </h2>
                  </div>
                  <div class="title-desc">
                    <p>We are offering wide range of Zari and Yarns in India and Overseas.</p>
                  </div>
                </div>
                <!-- section title end -->
              </div>
            </div>
            <!-- row end -->
          </div>
        </div>
      </div>
    </section>
    <!--padding_zero-section end-->
    <!--padding_top_zero-section-->
    <section class="ttm-row padding_top_zero-section mt_210 res-991-margin_top_30 position-relative z-index-2 clearfix">
      <div class="container">
        <!-- row -->
        <div class="row slick_slider" data-slick='{"slidesToShow": 3, "slidesToScroll": 1, "arrows":true, "autoplay":true, "dots":false, "infinite":true, "responsive":[{"breakpoint":992,"settings":{"slidesToShow": 2}},{"breakpoint":840,"settings":{"slidesToShow": 2}},{"breakpoint":650,"settings":{"slidesToShow": 1}}]}'>
          <div class="col-md-4 col-sm-6 wow fadeInUp animated">
            <!--featured-imagebox-->
            <div class="featured-imagebox featured-imagebox-services style1">
              <!-- featured-thumbnail -->
              <div class="featured-thumbnail"> <img class="img-fluid" src="images/Badla-Zari.jpg" alt="image"> </div>
              <!-- featured-thumbnail end-->
              <div class="featured-content">
                <div class="featured-title">
                  <h3><a href="flora-zari.php">Flora Zari (Jari Kasab)</a></h3>
                  <div class="ttm-details-link"> <a href="flora-zari.php"><i class="themifyicon ti-arrow-top-right"></i></a> </div>
                </div>
              </div>
            </div>
            <!-- featured-imagebox end-->
          </div>
   	  <div class="col-md-4 col-sm-6 wow fadeInUp animated">
            <!--featured-imagebox-->
            <div class="featured-imagebox featured-imagebox-services style1">
              <!-- featured-thumbnail -->
              <div class="featured-thumbnail"> <img class="img-fluid" src="images/polyester-yarn.jpg" alt="image"> </div>
              <!-- featured-thumbnail end-->
              <div class="featured-content">
                <div class="featured-title">
                  <h3><a href="polyester-yarn.php">Polyester Yarn </a></h3>
                  <div class="ttm-details-link"> <a href="polyester-yarn.php"><i class="themifyicon ti-arrow-top-right"></i></a> </div>
                </div>
              </div>
            </div>
            <!-- featured-imagebox end-->
          </div>
          <div class="col-md-4 col-sm-6 wow fadeInUp animated">
            <!--featured-imagebox-->
            <div class="featured-imagebox featured-imagebox-services style1">
              <!-- featured-thumbnail -->
              <div class="featured-thumbnail"> <img class="img-fluid" src="images/metallic-film.jpg" alt="image"> </div>
              <!-- featured-thumbnail end-->
              <div class="featured-content">
                <div class="featured-title">
                  <h3><a href="metallic-film.php">Metallic Film </a></h3>
                  <div class="ttm-details-link"> <a href="metallic-film.php"><i class="themifyicon ti-arrow-top-right"></i></a> </div>
                </div>
              </div>
            </div>
            <!-- featured-imagebox end-->
          </div>
          <div class="col-md-4 col-sm-6 wow fadeInUp animated">
            <!--featured-imagebox-->
            <div class="featured-imagebox featured-imagebox-services style1">
              <!-- featured-thumbnail -->
              <div class="featured-thumbnail"> <img class="img-fluid" src="images/viscose-yarn.jpg" alt="image"> </div>
              <!-- featured-thumbnail end-->
              <div class="featured-content">
                <div class="featured-title">
                  <h3><a href="viscose-yarn.php">Viscose Yarn </a></h3>
                  <div class="ttm-details-link"> <a href="viscose-yarn.php"><i class="themifyicon ti-arrow-top-right"></i></a> </div>
                </div>
              </div>
            </div>
            <!-- featured-imagebox end-->
          </div>
		  <div class="col-md-4 col-sm-6 wow fadeInUp animated">
            <!--featured-imagebox-->
            <div class="featured-imagebox featured-imagebox-services style1">
              <!-- featured-thumbnail -->
              <div class="featured-thumbnail"> <img class="img-fluid" src="images/thread.jpg" alt="image"> </div>
              <!-- featured-thumbnail end-->
              <div class="featured-content">
                <div class="featured-title">
                  <h3><a href="embroidery-thread.php">Embroidery Thread</a></h3>
                  <div class="ttm-details-link"> <a href="embroidery-thread.php"><i class="themifyicon ti-arrow-top-right"></i></a> </div>
                </div>
              </div>
            </div>
            <!-- featured-imagebox end-->
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12 text-center"> <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-square ttm-btn-style-border ttm-btn-color-dark margin_top30" href="flora-zari.php">View More</a> </div>
        </div>
        <!-- row end -->
      </div>
    </section>
    <!--padding_top_zero-section end -->
    <section class="ttm-row padding_zero-section ttm-bgcolor-skincolor bg-layer-equal-height clearfix">
      <div class="container">
        <div class="row no-gutters">
          <div class="col-lg-12">
            <div class="row">
              <div class="col-lg-7 col-md-12">
                <!-- col-img-img-two -->
                <div class="ttm-bg ttm-col-bgimage-yes col-bg-img-two ttm-left-span z-index-2">
                  <div class="ttm-col-wrapper-bg-layer ttm-bg-layer"></div>
                  <div class="layer-content"> </div>
                </div>
                <!-- col-img-bg-img-two end-->
                <img class="img-fluid ttm-equal-height-image w-100" src="images/col-bgimage-2.jpg" alt="bg-image" height="100%" width="100%"> </div>
              <div class="col-lg-5">
                <div class="padding_top30 padding_bottom30 text-lg-right res-1199-padding_right15 res-991-padding_left15">
                  <div class="fs-26">"Perfect Lenght is Our Motto"</div>
                </div>
                <div class="ttm-bg ttm-col-bgcolor-yes ttm-bgcolor-darkgrey ttm-bg ttm-right-span spacing-3 z-index-2 h-auto res-1199-padding_right15">
                  <div class="ttm-col-wrapper-bg-layer ttm-bg-layer">
                    <div class="ttm-col-wrapper-bg-layer-inner"></div>
                  </div>
                  <div class="layer-content wow fadeInUp animated">
                    <!-- section title -->
                    <div class="section-title">
                      <div class="title-header">
                        <h3>WHY US </h3>
                        <h2 class="title">Customer satisfaction and ethical business practice is <b>our priority</b> </h2>
                      </div>
                    </div>
                    <!-- section title end -->
                    <div class="row">
                      <div class="col-md-12 col-sm-6">
                        <!--featured-icon-box-->
                        <div class="featured-icon-box icon-align-before-title style2">
                          <div class="featured-icon">
                            <div class="ttm-icon ttm-icon_element-fill ttm-icon_element-style-rounded ttm-icon_element-color-skincolor ttm-icon_element-size-xs">
                              <div class="fa fa-check"></div>
                            </div>
                          </div>
                          <div class="featured-title">
                            <h3> All Thread Solution </h3>
                          </div>
                          <div class="featured-content">
                            <div class="featured-desc">
                              <p>All Flora Zari and Yarn solution In One Roof.

 </p>
                            </div>
                          </div>
                        </div>
                        <!-- featured-icon-box end-->
                      </div>
                      <div class="col-md-12 col-sm-6">
                        <!--featured-icon-box-->
                        <div class="featured-icon-box icon-align-before-title style2">
                          <div class="featured-icon">
                            <div class="ttm-icon ttm-icon_element-fill ttm-icon_element-style-rounded ttm-icon_element-color-skincolor ttm-icon_element-size-xs">
                              <div class="fa fa-check"></div>
                            </div>
                          </div>
                          <div class="featured-title">
                            <h3> Deliver On Time </h3>
                          </div>
                          <div class="featured-content">
                            <div class="featured-desc">
                              <p>We deliver timely all over india & abroad. </p>
                            </div>
                          </div>
                        </div>
                        <!-- featured-icon-box end-->
                      </div>
                      <div class="col-md-12 col-sm-6">
                        <!--featured-icon-box-->
                        <div class="featured-icon-box icon-align-before-title style2">
                          <div class="featured-icon">
                            <div class="ttm-icon ttm-icon_element-fill ttm-icon_element-style-rounded ttm-icon_element-color-skincolor ttm-icon_element-size-xs">
                              <div class="fa fa-check"></div>
                            </div>
                          </div>
                          <div class="featured-title">
                            <h3> Our Quality </h3>
                          </div>
                          <div class="featured-content">
                            <div class="featured-desc">
                              <p>Perfect quality & quantity. </p>
                            </div>
                          </div>
                        </div>
                        <!-- featured-icon-box end-->
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- row end -->
          </div>
        </div>
      </div>
    </section>
    <section class="ttm-row testimonial-section bg-img4 ttm-bgcolor-grey mt_70 res-991-margin_top0 clearfix">
      <div class="container">
        <!-- row -->
        <div class="row">
          <div class="col-lg-12">
            <div class="padding_top70 res-991-padding_top0"></div>
            <!-- section-title -->
            <div class="section-title title-style-center_text">
              <div class="title-header">
                <h3>TESTIMONIALS</h3>
                <h2 class="title">What Our Customers <b>Are Saying?</b></h2>
              </div>
            </div>
            <!-- section-title end -->
          </div>
        </div>
        <!-- row end -->
        <div class="row no-gutters slick_slider slick-arrows-style1" data-slick='{"slidesToShow": 3, "slidesToScroll": 1, "arrows":true, "centerMode":true, "centerPadding":0, "autoplay":false, "dots":false, "infinite":true, "responsive":[{"breakpoint":992,"settings":{"slidesToShow": 2}},{"breakpoint":840,"settings":{"slidesToShow": 2}},{"breakpoint":575,"settings":{"slidesToShow": 1}}]}'>
          <div class="col-lg-12 wow fadeInUp animated">
            <!-- testimonials -->
            <div class="testimonials ttm-testimonial-box-view-style2">
              <div class="testimonial-content">
                <blockquote class="testimonial-text">Your jari are vary good & thin so give more production & labour are running very easy. </blockquote>
                <div class="testimonial-bottom">
                  <div class="testimonial-avatar">
                    <div class="testimonial-img"> <img class="img-fluid" src="images/no-user.jpg" alt="testimonial-img"> </div>
                  </div>
                  <div class="testimonial-caption">
                    <h5> Rajesh Patel (Ahmedabad)</h5>
                    <label>Customer</label>
                  </div>
                </div>
              </div>
            </div>
            <!-- testimonials end -->
          </div>
          <div class="col-lg-12 wow fadeInUp animated">
            <!-- testimonials -->
            <div class="testimonials ttm-testimonial-box-view-style2">
              <div class="testimonial-content">
                <blockquote class="testimonial-text">Ganesh Thread have perfect length & extra shining. </blockquote>
                <div class="testimonial-bottom">
                  <div class="testimonial-avatar">
                    <div class="testimonial-img"> <img class="img-fluid" src="images/no-user.jpg" alt="testimonial-img"> </div>
                  </div>
                  <div class="testimonial-caption">
                    <h5>Mehul Rudani</h5>
                    <label>Customer</label>
                  </div>
                </div>
              </div>
            </div>
            <!-- testimonials end -->
          </div>
          <div class="col-lg-12 wow fadeInUp animated">
            <!-- testimonials -->
            <div class="testimonials ttm-testimonial-box-view-style2">
              <div class="testimonial-content">
                <blockquote class="testimonial-text">Polyster jarman & jari have large share range according to market so all color are available. </blockquote>
                <div class="testimonial-bottom">
                  <div class="testimonial-avatar">
                    <div class="testimonial-img"> <img class="img-fluid" src="images/no-user.jpg" alt="testimonial-img"> </div>
                  </div>
                  <div class="testimonial-caption">
                    <h5>Shantilal (Muktidham)</h5>
                    <label>Customer</label>
                  </div>
                </div>
              </div>
            </div>
            <!-- testimonials end -->
          </div>
          <div class="col-lg-12 wow fadeInUp animated">
            <!-- testimonials -->
            <div class="testimonials ttm-testimonial-box-view-style2">
              <div class="testimonial-content">
                <blockquote class="testimonial-text">zari have extra shining &smoothness so customer are satisfy. </blockquote>
                <div class="testimonial-bottom">
                  <div class="testimonial-avatar">
                    <div class="testimonial-img"> <img class="img-fluid" src="images/no-user.jpg" alt="testimonial-img"> </div>
                  </div>
                  <div class="testimonial-caption">
                    <h5>Panjab</h5>
                    <label>Customer</label>
                  </div>
                </div>
              </div>
            </div>
            <!-- testimonials end -->
          </div>
        </div>
      </div>
    </section>
    <!--testimonial-section end-->
    <!--service-section-->
    <!--service-section end -->
    <!--blog-section-->
    <section class="ttm-row blog-section clearfix">
      <div class="container">
        <!-- row -->
        <div class="row">
          <div class="col-lg-12">
            <!-- section title -->
            <div class="section-title style2">
              <div class="text-center">
                <h3>OUR BLOGS</h3>
                <h2 class="title">Latest <b>News And Articles!</b></h2>
              </div>
          
            </div>
            <!-- section title end -->
          </div>
        </div>
        <div class="row slick_slider mb_15" data-slick='{"slidesToShow": 3, "slidesToScroll": 1, "arrows":false, "dots":false, "autoplay":true, "infinite":true, "responsive": [{"breakpoint":1024,"settings":{"slidesToShow": 3}} , {"breakpoint":900,"settings":{"slidesToShow": 2}}, {"breakpoint":575,"settings":{"slidesToShow": 1}}]}'>
          <div class="col-lg-4 wow fadeInUp animated">
            <!-- featured-imagebox-post -->
            <div class="featured-imagebox featured-imagebox-post style1">
              <div class="featured-thumbnail"> <img class="img-fluid" src="images/blog-1.jpg" alt=""> </div>
              <div class="featured-content">
                <!-- ttm-box-post-date -->
                <div class="ttm-box-post-date"> <span class="ttm-entry-date">
                  <time class="entry-date" datetime="2021-03-18T04:16:25+00:00">18<span class="entry-month entry-year">Mar</span></time>
                  </span> </div>
                <!-- ttm-box-post-date end -->
                <div class="featured-title">
                  <h3><a href="#">Jari & Kasab</a></h3>
                </div>
                <div class="featured-desc">
                  <p>Jari & Kasab is use in different type of Embroidery work like Single & Multi Sequence Computerise Machine.</p>
                </div>
                <a class="ttm-btn ttm-btn-size-md ttm-btn-color-dark btn-inline" href="blog-single.html" tabindex="-1">Read More</a> </div>
            </div>
            <!-- featured-imagebox-post end -->
          </div>
          <div class="col-lg-4 wow fadeInUp animated">
            <!-- featured-imagebox-post -->
            <div class="featured-imagebox featured-imagebox-post style1">
              <div class="featured-thumbnail"> <img class="img-fluid" src="images/blog-2.jpg" alt=""> </div>
              <div class="featured-content">
                <!-- ttm-box-post-date -->
                <div class="ttm-box-post-date"> <span class="ttm-entry-date">
                  <time class="entry-date" datetime="2021-02-28T04:15:42+00:00">28<span class="entry-month entry-year">Feb</span></time>
                  </span> </div>
                <!-- post-meta end -->
                <div class="featured-title">
                  <h3><a href="#">Polyester, Reco Jarman Thread</a></h3>
                </div>
                <div class="featured-desc">
                  <p>Polyester Thread are made from Twisted Yarn Raw Materials. Which have also different Denier variant like, 100/2D, 120/2D...</p>
                </div>
                <a class="ttm-btn ttm-btn-size-md ttm-btn-color-dark btn-inline" href="blog-single.html">Read More</a> </div>
            </div>
            <!-- featured-imagebox-post end -->
          </div>
          <div class="col-lg-4 wow fadeInUp animated">
            <!-- featured-imagebox-post -->
            <div class="featured-imagebox featured-imagebox-post style1">
              <div class="featured-thumbnail"> <img class="img-fluid" src="images/blog-3.jpg" alt=""> </div>
              <div class="featured-content">
                <!-- ttm-box-post-date -->
                <div class="ttm-box-post-date"> <span class="ttm-entry-date">
                  <time class="entry-date" datetime="2021-03-18T04:16:25+00:00">18<span class="entry-month entry-year">Mar</span></time>
                  </span> </div>
                <!-- ttm-box-post-date end -->
                <div class="featured-title">
                  <h3><a href="#">Jari & Kasab</a></h3>
                </div>
                <div class="featured-desc">
                  <p>Jari & Kasab is use in different type of Embroidery work like Single & Multi Sequence Computerise Machine.</p>
                </div>
                <a class="ttm-btn ttm-btn-size-md ttm-btn-color-dark btn-inline" href="blog-single.html" tabindex="-1">Read More</a> </div>
            </div>
            <!-- featured-imagebox-post end -->
          </div>
        </div>
      </div>
    </section>
    <!--blog-section end-->
    <!--blog-section end-->
  </div>
  <!--site-main end-->
  <!--footer start-->
  <footer class="footer widget-footer ttm-bgcolor-darkgrey ttm-textcolor-white clearfix">
    <div class="second-footer">
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3 widget-area wow fadeInUp animated">
        <div class="widget widget-latest-tweets clearfix">
          <h6 class="">Shree Ganesh Jari Covering Pvt. Ltd.</h6>
          <ul class="widget_contact_wrapper">
            <li><i class="ttm-textcolor-skincolor fa fa-map-marker"></i> <b>Office</b><br/>3013, Central Bazar,<br/>
             Opp. Varachha Police Station,<br/>
              Varachha Main Road,<br/>
              Surat-395006,<br/>
              Gujarat, India </li>
            <li><i class="ttm-textcolor-skincolor fa fa-map-marker"></i> <b>Factory</b><br/>Block No 225, Plot No: 2 to 5,<br/>
             Shree Krishna Industrial Estate,<br/>
              Mota Borsara, Nr.Darbar Hotel,<br/>
              Kim, Surat-394110,<br/>
              Gujarat, India </li>
          </ul>
        </div>
      </div>
      <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3 offset-md-1 widget-area wow fadeInUp animated">
        <div class="widget widget-latest-tweets clearfix">
          <h6 class="">Contact Us</h6>
          <ul class="widget_contact_wrapper">
            <li><i class="ttm-textcolor-skincolor fa fa-phone"></i><a href="tel:918000971500"> +91 80009 71500</a></li>
            <li><i class="ttm-textcolor-skincolor fa fa-whatsapp"></i><a href="tel:919016025691"> +91 99047 71500</a></li>
            <li><i class="ttm-textcolor-skincolor fa fa-envelope-o"></i><a href="mailto:sales@ganeshthread.com"> sales@ganeshthread.com</a></li>
            <!--li><i class="ttm-textcolor-skincolor fa fa fa-map-marker"></i><a href="https://g.page/ganesh-jari-thread?gm" target="_blank">Map & Direction</a></li-->
          </ul>
        </div>
      </div>      
      <div class="col-xs-12  col-sm-6 col-md-6 col-lg-2 widget-area wow fadeInUp animated">
        <div class="widget widget_nav_menu clearfix">
          <h6 class="">Quick Links</h6>
          <ul id="menu-footer-quick-links" class="menu">
            <li><a href="index.php">Home</a></li>
            <li><a href="company-profile.php">About</a></li>
            <li><a href="dealer-network.php"> Dealer Network</a></li>
            <li><a href="photo-gallery.php">Gallery</a></li>
            <li><a href="inquiry.php">Dealership Inquiry</a></li>
            <li><a href="pay.php">Pay Online</a></li>
			<li><a href="contact-us.php">Contact Us</a></li>
            <li><a href="blog.php">Blog</a></li>
          </ul>
        </div>
      </div>
      <div class="col-xs-12 col-sm-6 col-md-6 col-lg-2 widget-area wow fadeInUp animated">
        <div class="widget widget_nav_menu clearfix">
          <h6 class="">Our Products</h6>
          <ul id="menu-footer-quick-links" class="menu">
            <li><a href="flora-zari.php">Flora Zari (Jari Kasab)</a></li>
            <li><a href="polyester-yarn.php">Polyester Yarn </a></li>
            <li><a href="cotton-yarn.php">Cotton Yarn </a></li>
            <li><a href="metallic-film.php">Metallic Film </a></li>
            <li><a href="viscose-yarn.php">Viscose Yarn </a></li>
            <li><a href="embroidery-thread.php">Embroidery  Thread</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="bottom-footer-text copyright">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 text-center">
        <div class="widget widget_social clearfix">
          <div class="social-icons">
            <ul class="social-icons list-inline">
              <li><a class="tooltip-top" href="https://www.facebook.com/ganeshjaricovering" target="_blank" rel="noopener" aria-label="facebook" data-tooltip="Facebook"><i class="fa fa-facebook"></i></a></li>
              <li><a class="tooltip-top" href="https://www.instagram.com/shreeganeshjaricovering/" target="_blank" rel="noopener" aria-label="instagram" data-tooltip="Instagram"><i class="fa fa-instagram"></i></a></li>
              <li><a class="tooltip-top" href="https://twitter.com/ShreeJari?s=09" target="_blank" rel="noopener" aria-label="twitter" data-tooltip="Twitter"><i class="fa fa-twitter"></i></a></li>
              <li><a class="tooltip-top" href="https://in.pinterest.com/ganeshjari2015/" target="_blank" rel="noopener" aria-label="pinterest" data-tooltip="Pinterest"><i class="fa fa-pinterest"></i></a></li>
              <li><a class="tooltip-top" href="https://www.linkedin.com/in/ganesh-jari-thread-87473919b/" target="_blank" rel="noopener" aria-label="linkedin" data-tooltip="Linkedin"><i class="fa fa-linkedin"></i></a></li>
              <li><a class="tooltip-top" href="https://www.youtube.com/channel/UCrhCuUlYXh9meL4NEGJbDUQ?view_as=subscriber" target="_blank" rel="noopener" aria-label="youtube" data-tooltip="Youtube"><i class="fa fa-youtube"></i></a></li>
              <li><a class="tooltip-top" href="https://t.me/Ganeshjari14" target="_blank" rel="noopener" aria-label="telegram" data-tooltip="Telegram"><i class="fa fa-telegram" aria-hidden="true"></i> </a></li>
              <li><a class="tooltip-top" href="https://www.google.com/maps/place//data=!4m2!3m1!1s0x3be047456bfe347d:0xb9d32c48cedd3813?source=g.page.m" target="_blank" rel="noopener" aria-label="Map and Direction" data-tooltip="Map and Direction"><i class="fa fa-map-marker" aria-hidden="true"></i> </a></li>
            </ul>
          </div>
        </div>
        <br/>
        <div class="text-center"> <span class="cpy-text">Copyright &copy; 2021 <a href="#" class="ttm-textcolor-skincolor font-weight-500">Shree Ganesh Jari Covering</a> All rights reserved.</span> </div>
      </div>
    </div>
  </div>
</div>
  </footer>
  <!--footer end-->
  <!--back-to-top start-->
  <a id="totop" href="#top"> <i class="fa fa-angle-up"></i> </a>
  <!--back-to-top end-->
</div>
<!-- page end -->
<!-- Javascript -->
<script src="./js/jquery.js"></script>
<script src="./js/popper.min.js"></script>
<script src="./js/wow.js"></script>
<!-- main-js -->
<script src="./js/script.js"></script>
<script src="./js/popper.min.js"></script>
<script src="./js/bootstrap.min.js"></script>
<script src="./js/appear.js"></script>
<script src="js/jquery-3.6.0.min.js"></script>
<script src="js/jquery-migrate-3.3.2.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.easing.js"></script>
<script src="./js/scrollbar.js"></script>
<script src="js/jquery-waypoints.js"></script>
<script src="js/jquery-validate.js"></script>
<script src="js/jquery.prettyPhoto.js"></script>
<script src="js/slick.min.js"></script>
<script src="js/numinate.min.js"></script>
<script src="js/imagesloaded.min.js"></script>
<script src="js/jquery-isotope.js"></script>
<script src="js/main.js"></script><!-- Javascript end-->
</body>
</html>
