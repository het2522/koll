<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Dealer Network</title>
<link rel="shortcut icon" href="images/feviacon.png" />
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="css/animate.css"/>
<link rel="stylesheet" type="text/css" href="css/font-awesome.css"/>
<link rel="stylesheet" type="text/css" href="css/flaticon.css"/>
<link rel="stylesheet" type="text/css" href="css/themify-icons.css"/>
<link rel="stylesheet" type="text/css" href="css/slick.css">
<link rel="stylesheet" type="text/css" href="css/prettyPhoto.css">
<link rel="stylesheet" type="text/css" href="css/shortcodes.css"/>
<link rel="stylesheet" type="text/css" href="css/main.css"/>
<link rel="stylesheet" type="text/css" href="css/megamenu.css"/>
<link rel="stylesheet" type="text/css" href="css/responsive.css"/>
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css"/>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="facebook-domain-verification" content="znjsxsn8b4ry84qap5vw4hp7w2snve" />

<!-- Google tag (gtag.js) --> <script async src="https://www.googletagmanager.com/gtag/js?id=AW-669623619"></script> <script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'AW-669623619'); </script><link rel="stylesheet" href="./css/map.css">
<link rel="stylesheet" href="./css/map-animation.css">
</head>
<body>
<!--page start-->
<div class="page">
  <header id="masthead" class="header ttm-header-style-03">
    
<div class="inspiro-whatsapp-icon">
  <div><a target="_blank" href="https://api.whatsapp.com/send?phone=919904771500&amp;text=I am Interested in Ganesh Jari &amp; Thread"><img src="./images/whatsapp.png"> Let's Connect</a></div>
</div>
<!-- topbar -->
<div class="top_bar ttm-bgcolor-darkgrey clearfix">
  <div class="container">
    <div class="row no-gutters">
      <div class="col-xl-12 d-flex flex-row align-items-center">
        <div class="top_bar_contact_item">
          <div class="top_bar_icon"><i class="ti ti-email"></i></div>
          <a href="mailto:sales@ganeshthread.com">sales@ganeshthread.com</a> </div>
        <div class="top_bar_contact_item">
          <div class="top_bar_icon"><i class="ti ti-file"></i></div>
          <a href="./images/brochure/ganesh-jari-covering-broucher.pdf" target="_blank">Brochure</a>
        </div>
        <div class="top_bar_contact_item">
          <div class="top_bar_icon"><i class="fa fa-inr"></i></div>
          <a href="pay.php">Pay Online</a>
        </div>
        <div class="top_bar_contact_item top_bar_social ml-auto p-0">
          <ul class="social-icons list-inline">
            <li><a class="tooltip-top" href="https://www.facebook.com/ganeshjaricovering" target="_blank" rel="noopener" aria-label="facebook" data-tooltip="Facebook"><i class="fa fa-facebook"></i></a></li>
            <li><a class="tooltip-top" href="https://www.instagram.com/shreeganeshjaricovering/" target="_blank" rel="noopener" aria-label="instagram" data-tooltip="instagram"><i class="fa fa-instagram"></i></a></li>
            <li><a class="tooltip-top" href="https://twitter.com/ShreeJari?s=09" target="_blank" rel="noopener" aria-label="twitter" data-tooltip="twitter"><i class="fa fa-twitter"></i></a></li>
            <li><a class="tooltip-top" href="https://in.pinterest.com/ganeshjari2015/" target="_blank" rel="noopener" aria-label="pinterest" data-tooltip="pinterest"><i class="fa fa-pinterest"></i></a></li>
            <li><a class="tooltip-top" href="https://www.linkedin.com/in/ganesh-jari-thread-87473919b/" target="_blank" rel="noopener" aria-label="linkedin" data-tooltip="linkedin"><i class="fa fa-linkedin"></i></a></li>
            <li><a class="tooltip-top" href="https://www.youtube.com/channel/UCrhCuUlYXh9meL4NEGJbDUQ?view_as=subscriber" target="_blank" rel="noopener" aria-label="youtube" data-tooltip="Youtube"><i class="fa fa-youtube"></i></a></li>
            <li><a class="tooltip-top" href="https://t.me/Ganeshjari14" target="_blank" rel="noopener" aria-label="telegram" data-tooltip="telegram"><i class="fa fa-telegram" aria-hidden="true"></i> </a></li>
            <li><a class="tooltip-top" href="https://www.google.com/maps/place//data=!4m2!3m1!1s0x3be047456bfe347d:0xb9d32c48cedd3813?source=g.page.m" target="_blank" rel="noopener" aria-label="Map and Direction" data-tooltip="Map and Direction"><i class="fa fa-map-marker" aria-hidden="true"></i> </a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- topbar end -->
<!-- site-header-menu -->
<div id="site-header-menu" class="site-header-menu ttm-bgcolor-white">
  <div class="site-header-menu-inner ttm-stickable-header">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <!--site-navigation -->
          <div class="site-navigation d-flex flex-row align-items-center justify-content-between">
            <!-- site-branding -->
            <div class="site-branding "> <a class="home-link" href="index.php" title="Shree Ganesh Jari Covering - All Thred Solution Provider" rel="home"> <img id="logo-img" class="img-fluid auto_size" src="images/logo.png" alt="logo-img"> </a> </div>
            <!-- site-branding end -->
            <div class="d-flex flex-row m-auto">
              <div class="btn-show-menu-mobile menubar menubar--squeeze"> <span class="menubar-box"> <span class="menubar-inner"></span> </span> </div>
              <!-- menu -->
              <nav class="main-menu menu-mobile" id="menu">
                <ul class="menu">
                  <li class="mega-menu-item active"> <a href="index.php">Home</a> </li>
                  <li class="mega-menu-item"> <a href="#" class="mega-menu-link">About</a>
                    <ul class="mega-submenu">
                      <li><a href="company-profile.php">Company Profile</a></li>
                      <li><a href="commitment-achievment.php">Commitment  & Achievment</a></li>
                    </ul>
                  </li>
                  <li class="mega-menu-item"> <a href="#" class="mega-menu-link">Products</a>
                    <ul class="mega-submenu">
                      <li><a href="flora-zari.php">Flora Zari (Jari Kasab)</a></li>
                      <li><a href="polyester-yarn.php">Polyester Yarn </a></li>
                      <li><a href="cotton-yarn.php">Cotton Yarn </a></li>
                      <li><a href="metallic-film.php">Metallic Film </a></li>
                      <li><a href="viscose-yarn.php">Viscose Yarn </a></li>
                      <li><a href="embroidery-thread.php">Embroidery  Thread</a></li>
                    </ul>
                  </li>
                  <li class="mega-menu-item"> <a href="#" class="mega-menu-link">Gallery</a>
                    <ul class="mega-submenu">
                      <li><a href="photo-gallery.php">Photo Gallery</a></li>
                      <li><a href="videos.php">Video</a></li>
                      <li><a href="exhibition.php">Exhibition</a></li>
                    </ul>
                  </li>
                  <!-- <li class="mega-menu-item"><a href="exhibition.php">Exhibition</a></li> -->
                  <li class="mega-menu-item"><a href="blog.php">Blog</a></li>
                  <li class="mega-menu-item"><a href="#" class="mega-menu-link">Dealer</a>
                    <ul class="mega-submenu">
                      <li><a href="dealer-network.php">Dealer Network</a></li>
                      <li><a href="inquiry.php">Dealership Inquiry</a> </li>
                    </ul>
                  </li>
                  <!-- https://docs.google.com/forms/d/1l7_klgSXvWV_t5MKjUQKfswPoY66dn9F3RYIZF8FYMY/edit -->
                  <!-- <li class="mega-menu-item"> <a href="https://docs.google.com/forms/d/e/1FAIpQLSd3IjkrCkFWh9lJ7XRCf77bDSXFGUnQ5vwtuJqVwR2LPdVBLQ/viewform?usp=sf_link" target="_blank">Dealership Inquiry</a> </li> -->
                  <li class="mega-menu-item"> <a href="contact-us.php">Contact</a> </li>
                </ul>
              </nav>
              <!-- menu end -->
            </div>
            <div class="widget_info d-flex flex-row align-items-center">
              <div class="widget_icon ttm-textcolor-skincolor"><i class="flaticon-phone-call"></i></div>
              <div class="widget_content">
                <h3 class="widget_title"><a href="tel:918000971500"> +91 80009 71500 </a></h3>
                <p class="widget_desc">Customer Care</p>
              </div>
            </div>
          </div>
          <!-- site-navigation end-->
        </div>
      </div>
    </div>
  </div>
</div>
<!-- site-header-menu end-->
  </header>
  <!-- Banner -->
  <div class="ttm-page-title-row ttm-bg ttm-bgimage-yes ttm-bgcolor-darkgrey clearfix">
    <div class="ttm-row-wrapper-bg-layer ttm-bg-layer"></div>
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-12">
          <div class="ttm-page-title-row-inner">
            <div class="page-title-heading">
              <h2 class="title">Dealer Network </h2>
            </div>
            <div class="breadcrumb-wrapper"> <span> <a title="Homepage" href="#">Home</a> </span> <span>Dealer Network </span> </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Banner end-->
  <!--site-main start-->
  <div class="site-main">
    <!--padding_zero-section-->
    <!--padding_zero-section-->
    <section class="ttm-row about-section clearfix">
      <div class="container">
        <div class="section-title title-style-center_text">
          <div class="title-header">
            <h2 class="title">Dealer Network - <b>World Wide</b></h2>
          </div>
        </div>
        <div class="row">
          <div class="elementor-7 col-md-12">
            <div class="elementor-element elementor-element-78ba836 elementor-widget elementor-widget-elementskit-hotspot" data-id="78ba836" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-hotspot.default">
              <div class="elementor-widget-container">
                <div class="ekit-wid-con" >
                  <div class="ekit-location-groups">
                    <div class="ekit-map-image text-center"> <img src="./images/map.png" alt="map" width="1500"> </div>
                    <div class="ekit-location-wraper clearfix">
                      <div class="ekit-location elementor-repeater-item-us">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>United States </p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-srilanka">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Sri Lanka </p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-bhutan">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Bhutan</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-canada">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Canada</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-jamaica">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Jamaica</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-australia">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Australia </p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-china">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>China </p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-iceland">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Iceland </p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-uk">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>United Kingdom </p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-germany">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Germany</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-cyprus">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Cyprus</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-north-macedonia">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>North Macedonia</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-netherlands">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Netherlands</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-france">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>France</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-algeria">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Algeria</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-south-africa">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>South Africa</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-switzerland">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Switzerland</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-angola">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Angola</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-yemen">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Yemen</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-oman">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Oman</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-uae">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>UAE</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-uzbekistan">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Uzbekistan</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-argentina">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Argentina</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-singapore">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Singapore </p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-indonesia">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Indonesia </p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-japan">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Japan</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-bangladesh">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Bangladesh </p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-india">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>India</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                    </div>
                    <!-- .location-wraper END -->
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
		<div class="container">
        <div class="list-map">
          <ul class="ttm-list ttm-list-style-icon ttm-list-icon-color-skincolor margin_top15">
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">India </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">United States </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Bangladesh </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Canada </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Yemen </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Sri Lanka </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">North Macedonia </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Singapore </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Bhutan </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">China </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Germany </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Japan </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Netherlands </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Oman </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Uzbekistan </div>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">South Africa </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">United Arab Emirates </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Angola </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Argentina </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Australia </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Switzerland </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Cyprus </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Algeria </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">France </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">United Kingdom </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Indonesia </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Iceland </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Jamaica </div>
            </li>
          </ul>
        </div>
		</li>
      </div>
    </section>
    <section class="ttm-row about-section clearfix ttm-bgcolor-grey">
      <div class="container">
        <div class="section-title title-style-center_text">
          <div class="title-header">
            <h2 class="title">Dealer Network - <b>India</b></h2>
          </div>
        </div>
        <div class="row">
          <div class="elementor-7 col-md-12">
            <div class="elementor-element elementor-element-78ba836 elementor-widget elementor-widget-elementskit-hotspot" data-id="78ba836" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-hotspot.default">
              <div class="elementor-widget-container">
                <div class="ekit-wid-con" >
                  <div class="ekit-location-groups">
                    <div class="ekit-map-image text-center"> <img src="./images/india.png" alt="map" width=""> </div>
                    <div class="ekit-location-wraper clearfix">
                      <div class="ekit-location elementor-repeater-item-gujarat">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Gujarat</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-mp">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Madhya Pradesh</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-maharastra">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Maharastra</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-kerala">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Kerala</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-tamil-nadu">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Tamil nadu</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-karnataka">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Karnataka</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-andhra-pradesh">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Andhra Pradesh</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-telagana">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Telagana</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-west-bangal">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>West Bangal</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-bihar">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Bihar</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-up">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Uttar Pradesh</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-delhi">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Delhi</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-rajsthan">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Rajsthan</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                      <div class="ekit-location elementor-repeater-item-panjab">
                        <div class="media ekit-location_inner">
                          <div class="ekit_hotspot_arrow"></div>
                          <div class="ekit_hotspot_image"> <img src='./images/mapicon.png' class='mr-3' alt=''> </div>
                          <div class='media-body'>
                            <p class='ekit-location-des'>Panjab</p>
                          </div>
                        </div>
                        <div class="ekit-location_indicator">
                          <div class="ekit_hotspot_pulse_1"></div>
                          <div class="ekit_hotspot_pulse_2"></div>
                        </div>
                      </div>
                    </div>
                    <!-- .location-wraper END -->
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
		<div class="container">
        <div class="list-map">
          <ul class="ttm-list ttm-list-style-icon ttm-list-icon-color-skincolor margin_top15">
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Gujarat </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Uttar Pradesh </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Madhya Pradesh </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Maharashtra </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Kerla </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Panjab </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Delhi </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Karnataka </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Tamil nadu </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Rajsthan </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">West Bangal </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Telagana </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Andhra Pradesh </div>
            </li>
            <li><i class="ti ti-check"></i>
              <div class="ttm-list-li-content">Bihar </div>
            </li>
          </ul>
        </div>
		</div>
      </div>
    </section>
    <!--fid-section end-->
    <!--padding_zero-section-->
    <!--padding_zero-section end-->
    <!--padding_top_zero-section-->
    <!--padding_top_zero-section end -->
    <!--testimonial-section end-->
    <!--service-section-->
    <!--service-section end -->
    <!--blog-section-->
    <!--blog-section end-->
    <!--blog-section end-->
  </div>
  <!--site-main end-->
  <!--footer start-->
  <footer class="footer widget-footer ttm-bgcolor-darkgrey ttm-textcolor-white clearfix">
    <div class="second-footer">
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3 widget-area wow fadeInUp animated">
        <div class="widget widget-latest-tweets clearfix">
          <h6 class="">Shree Ganesh Jari Covering Pvt. Ltd.</h6>
          <ul class="widget_contact_wrapper">
            <li><i class="ttm-textcolor-skincolor fa fa-map-marker"></i> <b>Office</b><br/>3013, Central Bazar,<br/>
             Opp. Varachha Police Station,<br/>
              Varachha Main Road,<br/>
              Surat-395006,<br/>
              Gujarat, India </li>
            <li><i class="ttm-textcolor-skincolor fa fa-map-marker"></i> <b>Factory</b><br/>Block No 225, Plot No: 2 to 5,<br/>
             Shree Krishna Industrial Estate,<br/>
              Mota Borsara, Nr.Darbar Hotel,<br/>
              Kim, Surat-394110,<br/>
              Gujarat, India </li>
          </ul>
        </div>
      </div>
      <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3 offset-md-1 widget-area wow fadeInUp animated">
        <div class="widget widget-latest-tweets clearfix">
          <h6 class="">Contact Us</h6>
          <ul class="widget_contact_wrapper">
            <li><i class="ttm-textcolor-skincolor fa fa-phone"></i><a href="tel:918000971500"> +91 80009 71500</a></li>
            <li><i class="ttm-textcolor-skincolor fa fa-whatsapp"></i><a href="tel:919016025691"> +91 99047 71500</a></li>
            <li><i class="ttm-textcolor-skincolor fa fa-envelope-o"></i><a href="mailto:sales@ganeshthread.com"> sales@ganeshthread.com</a></li>
            <!--li><i class="ttm-textcolor-skincolor fa fa fa-map-marker"></i><a href="https://g.page/ganesh-jari-thread?gm" target="_blank">Map & Direction</a></li-->
          </ul>
        </div>
      </div>      
      <div class="col-xs-12  col-sm-6 col-md-6 col-lg-2 widget-area wow fadeInUp animated">
        <div class="widget widget_nav_menu clearfix">
          <h6 class="">Quick Links</h6>
          <ul id="menu-footer-quick-links" class="menu">
            <li><a href="index.php">Home</a></li>
            <li><a href="company-profile.php">About</a></li>
            <li><a href="dealer-network.php"> Dealer Network</a></li>
            <li><a href="photo-gallery.php">Gallery</a></li>
            <li><a href="inquiry.php">Dealership Inquiry</a></li>
            <li><a href="pay.php">Pay Online</a></li>
			<li><a href="contact-us.php">Contact Us</a></li>
            <li><a href="blog.php">Blog</a></li>
          </ul>
        </div>
      </div>
      <div class="col-xs-12 col-sm-6 col-md-6 col-lg-2 widget-area wow fadeInUp animated">
        <div class="widget widget_nav_menu clearfix">
          <h6 class="">Our Products</h6>
          <ul id="menu-footer-quick-links" class="menu">
            <li><a href="flora-zari.php">Flora Zari (Jari Kasab)</a></li>
            <li><a href="polyester-yarn.php">Polyester Yarn </a></li>
            <li><a href="cotton-yarn.php">Cotton Yarn </a></li>
            <li><a href="metallic-film.php">Metallic Film </a></li>
            <li><a href="viscose-yarn.php">Viscose Yarn </a></li>
            <li><a href="embroidery-thread.php">Embroidery  Thread</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="bottom-footer-text copyright">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 text-center">
        <div class="widget widget_social clearfix">
          <div class="social-icons">
            <ul class="social-icons list-inline">
              <li><a class="tooltip-top" href="https://www.facebook.com/ganeshjaricovering" target="_blank" rel="noopener" aria-label="facebook" data-tooltip="Facebook"><i class="fa fa-facebook"></i></a></li>
              <li><a class="tooltip-top" href="https://www.instagram.com/shreeganeshjaricovering/" target="_blank" rel="noopener" aria-label="instagram" data-tooltip="Instagram"><i class="fa fa-instagram"></i></a></li>
              <li><a class="tooltip-top" href="https://twitter.com/ShreeJari?s=09" target="_blank" rel="noopener" aria-label="twitter" data-tooltip="Twitter"><i class="fa fa-twitter"></i></a></li>
              <li><a class="tooltip-top" href="https://in.pinterest.com/ganeshjari2015/" target="_blank" rel="noopener" aria-label="pinterest" data-tooltip="Pinterest"><i class="fa fa-pinterest"></i></a></li>
              <li><a class="tooltip-top" href="https://www.linkedin.com/in/ganesh-jari-thread-87473919b/" target="_blank" rel="noopener" aria-label="linkedin" data-tooltip="Linkedin"><i class="fa fa-linkedin"></i></a></li>
              <li><a class="tooltip-top" href="https://www.youtube.com/channel/UCrhCuUlYXh9meL4NEGJbDUQ?view_as=subscriber" target="_blank" rel="noopener" aria-label="youtube" data-tooltip="Youtube"><i class="fa fa-youtube"></i></a></li>
              <li><a class="tooltip-top" href="https://t.me/Ganeshjari14" target="_blank" rel="noopener" aria-label="telegram" data-tooltip="Telegram"><i class="fa fa-telegram" aria-hidden="true"></i> </a></li>
              <li><a class="tooltip-top" href="https://www.google.com/maps/place//data=!4m2!3m1!1s0x3be047456bfe347d:0xb9d32c48cedd3813?source=g.page.m" target="_blank" rel="noopener" aria-label="Map and Direction" data-tooltip="Map and Direction"><i class="fa fa-map-marker" aria-hidden="true"></i> </a></li>
            </ul>
          </div>
        </div>
        <br/>
        <div class="text-center"> <span class="cpy-text">Copyright &copy; 2021 <a href="#" class="ttm-textcolor-skincolor font-weight-500">Shree Ganesh Jari Covering</a> All rights reserved.</span> </div>
      </div>
    </div>
  </div>
</div>
  </footer>
  <!--footer end-->
  <!--back-to-top start-->
  <a id="totop" href="#top"> <i class="fa fa-angle-up"></i> </a>
  <!--back-to-top end-->
</div>
<!-- page end -->
<!-- Javascript -->
<script src="./js/jquery.js"></script>
<script src="./js/popper.min.js"></script>
<script src="./js/wow.js"></script>
<!-- main-js -->
<script src="./js/script.js"></script>
<script src="./js/popper.min.js"></script>
<script src="./js/bootstrap.min.js"></script>
<script src="./js/appear.js"></script>
<script src="js/jquery-3.6.0.min.js"></script>
<script src="js/jquery-migrate-3.3.2.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.easing.js"></script>
<script src="./js/scrollbar.js"></script>
<script src="js/jquery-waypoints.js"></script>
<script src="js/jquery-validate.js"></script>
<script src="js/jquery.prettyPhoto.js"></script>
<script src="js/slick.min.js"></script>
<script src="js/numinate.min.js"></script>
<script src="js/imagesloaded.min.js"></script>
<script src="js/jquery-isotope.js"></script>
<script src="js/main.js"></script><!-- Javascript end-->
</body>
</html>
