<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Exhibition</title>
    <link rel="shortcut icon" href="images/feviacon.png" />
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="css/animate.css"/>
<link rel="stylesheet" type="text/css" href="css/font-awesome.css"/>
<link rel="stylesheet" type="text/css" href="css/flaticon.css"/>
<link rel="stylesheet" type="text/css" href="css/themify-icons.css"/>
<link rel="stylesheet" type="text/css" href="css/slick.css">
<link rel="stylesheet" type="text/css" href="css/prettyPhoto.css">
<link rel="stylesheet" type="text/css" href="css/shortcodes.css"/>
<link rel="stylesheet" type="text/css" href="css/main.css"/>
<link rel="stylesheet" type="text/css" href="css/megamenu.css"/>
<link rel="stylesheet" type="text/css" href="css/responsive.css"/>
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css"/>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="facebook-domain-verification" content="znjsxsn8b4ry84qap5vw4hp7w2snve" />

<!-- Google tag (gtag.js) --> <script async src="https://www.googletagmanager.com/gtag/js?id=AW-669623619"></script> <script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'AW-669623619'); </script></head>
<link rel="stylesheet" href="./css/carousel-lightbox.css">
<link href="./css/lightgallery.css" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function() {
    $('#lightgallery').lightGallery();
});
</script>
<script src="./js/lightgallery-all.min.js"></script>
<script src="./js/jquery.mousewheel.min.js"></script>

<body>
    <!--page start-->
    <div class="page">
        <header id="masthead" class="header ttm-header-style-03">
            
<div class="inspiro-whatsapp-icon">
  <div><a target="_blank" href="https://api.whatsapp.com/send?phone=919904771500&amp;text=I am Interested in Ganesh Jari &amp; Thread"><img src="./images/whatsapp.png"> Let's Connect</a></div>
</div>
<!-- topbar -->
<div class="top_bar ttm-bgcolor-darkgrey clearfix">
  <div class="container">
    <div class="row no-gutters">
      <div class="col-xl-12 d-flex flex-row align-items-center">
        <div class="top_bar_contact_item">
          <div class="top_bar_icon"><i class="ti ti-email"></i></div>
          <a href="mailto:sales@ganeshthread.com">sales@ganeshthread.com</a> </div>
        <div class="top_bar_contact_item">
          <div class="top_bar_icon"><i class="ti ti-file"></i></div>
          <a href="./images/brochure/ganesh-jari-covering-broucher.pdf" target="_blank">Brochure</a>
        </div>
        <div class="top_bar_contact_item">
          <div class="top_bar_icon"><i class="fa fa-inr"></i></div>
          <a href="pay.php">Pay Online</a>
        </div>
        <div class="top_bar_contact_item top_bar_social ml-auto p-0">
          <ul class="social-icons list-inline">
            <li><a class="tooltip-top" href="https://www.facebook.com/ganeshjaricovering" target="_blank" rel="noopener" aria-label="facebook" data-tooltip="Facebook"><i class="fa fa-facebook"></i></a></li>
            <li><a class="tooltip-top" href="https://www.instagram.com/shreeganeshjaricovering/" target="_blank" rel="noopener" aria-label="instagram" data-tooltip="instagram"><i class="fa fa-instagram"></i></a></li>
            <li><a class="tooltip-top" href="https://twitter.com/ShreeJari?s=09" target="_blank" rel="noopener" aria-label="twitter" data-tooltip="twitter"><i class="fa fa-twitter"></i></a></li>
            <li><a class="tooltip-top" href="https://in.pinterest.com/ganeshjari2015/" target="_blank" rel="noopener" aria-label="pinterest" data-tooltip="pinterest"><i class="fa fa-pinterest"></i></a></li>
            <li><a class="tooltip-top" href="https://www.linkedin.com/in/ganesh-jari-thread-87473919b/" target="_blank" rel="noopener" aria-label="linkedin" data-tooltip="linkedin"><i class="fa fa-linkedin"></i></a></li>
            <li><a class="tooltip-top" href="https://www.youtube.com/channel/UCrhCuUlYXh9meL4NEGJbDUQ?view_as=subscriber" target="_blank" rel="noopener" aria-label="youtube" data-tooltip="Youtube"><i class="fa fa-youtube"></i></a></li>
            <li><a class="tooltip-top" href="https://t.me/Ganeshjari14" target="_blank" rel="noopener" aria-label="telegram" data-tooltip="telegram"><i class="fa fa-telegram" aria-hidden="true"></i> </a></li>
            <li><a class="tooltip-top" href="https://www.google.com/maps/place//data=!4m2!3m1!1s0x3be047456bfe347d:0xb9d32c48cedd3813?source=g.page.m" target="_blank" rel="noopener" aria-label="Map and Direction" data-tooltip="Map and Direction"><i class="fa fa-map-marker" aria-hidden="true"></i> </a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- topbar end -->
<!-- site-header-menu -->
<div id="site-header-menu" class="site-header-menu ttm-bgcolor-white">
  <div class="site-header-menu-inner ttm-stickable-header">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <!--site-navigation -->
          <div class="site-navigation d-flex flex-row align-items-center justify-content-between">
            <!-- site-branding -->
            <div class="site-branding "> <a class="home-link" href="index.php" title="Shree Ganesh Jari Covering - All Thred Solution Provider" rel="home"> <img id="logo-img" class="img-fluid auto_size" src="images/logo.png" alt="logo-img"> </a> </div>
            <!-- site-branding end -->
            <div class="d-flex flex-row m-auto">
              <div class="btn-show-menu-mobile menubar menubar--squeeze"> <span class="menubar-box"> <span class="menubar-inner"></span> </span> </div>
              <!-- menu -->
              <nav class="main-menu menu-mobile" id="menu">
                <ul class="menu">
                  <li class="mega-menu-item active"> <a href="index.php">Home</a> </li>
                  <li class="mega-menu-item"> <a href="#" class="mega-menu-link">About</a>
                    <ul class="mega-submenu">
                      <li><a href="company-profile.php">Company Profile</a></li>
                      <li><a href="commitment-achievment.php">Commitment  & Achievment</a></li>
                    </ul>
                  </li>
                  <li class="mega-menu-item"> <a href="#" class="mega-menu-link">Products</a>
                    <ul class="mega-submenu">
                      <li><a href="flora-zari.php">Flora Zari (Jari Kasab)</a></li>
                      <li><a href="polyester-yarn.php">Polyester Yarn </a></li>
                      <li><a href="cotton-yarn.php">Cotton Yarn </a></li>
                      <li><a href="metallic-film.php">Metallic Film </a></li>
                      <li><a href="viscose-yarn.php">Viscose Yarn </a></li>
                      <li><a href="embroidery-thread.php">Embroidery  Thread</a></li>
                    </ul>
                  </li>
                  <li class="mega-menu-item"> <a href="#" class="mega-menu-link">Gallery</a>
                    <ul class="mega-submenu">
                      <li><a href="photo-gallery.php">Photo Gallery</a></li>
                      <li><a href="videos.php">Video</a></li>
                      <li><a href="exhibition.php">Exhibition</a></li>
                    </ul>
                  </li>
                  <!-- <li class="mega-menu-item"><a href="exhibition.php">Exhibition</a></li> -->
                  <li class="mega-menu-item"><a href="blog.php">Blog</a></li>
                  <li class="mega-menu-item"><a href="#" class="mega-menu-link">Dealer</a>
                    <ul class="mega-submenu">
                      <li><a href="dealer-network.php">Dealer Network</a></li>
                      <li><a href="inquiry.php">Dealership Inquiry</a> </li>
                    </ul>
                  </li>
                  <!-- https://docs.google.com/forms/d/1l7_klgSXvWV_t5MKjUQKfswPoY66dn9F3RYIZF8FYMY/edit -->
                  <!-- <li class="mega-menu-item"> <a href="https://docs.google.com/forms/d/e/1FAIpQLSd3IjkrCkFWh9lJ7XRCf77bDSXFGUnQ5vwtuJqVwR2LPdVBLQ/viewform?usp=sf_link" target="_blank">Dealership Inquiry</a> </li> -->
                  <li class="mega-menu-item"> <a href="contact-us.php">Contact</a> </li>
                </ul>
              </nav>
              <!-- menu end -->
            </div>
            <div class="widget_info d-flex flex-row align-items-center">
              <div class="widget_icon ttm-textcolor-skincolor"><i class="flaticon-phone-call"></i></div>
              <div class="widget_content">
                <h3 class="widget_title"><a href="tel:918000971500"> +91 80009 71500 </a></h3>
                <p class="widget_desc">Customer Care</p>
              </div>
            </div>
          </div>
          <!-- site-navigation end-->
        </div>
      </div>
    </div>
  </div>
</div>
<!-- site-header-menu end-->
        </header>
        <!-- Banner -->
        <div class="ttm-page-title-row ttm-bg ttm-bgimage-yes ttm-bgcolor-darkgrey clearfix">
            <div class="ttm-row-wrapper-bg-layer ttm-bg-layer"></div>
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-12">
                        <div class="ttm-page-title-row-inner">
                            <div class="page-title-heading">
                                <h2 class="title">Exhibition</h2>
                            </div>
                            <div class="breadcrumb-wrapper"> <span> <a title="Homepage" href="#">Home</a> </span> <span>Exhibition</span> </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Banner end-->
        <!--site-main start-->
        <div class="site-main">
            <!--padding_zero-section-->
            <!--padding_zero-section-->
            <section class="ttm-row about-section clearfix">
                <div class="container col-md-12">
                    <!-- row -->
                    <div class="home-layout row">

                        <div class="col-lg-4 wow fadeInUp animated animated" data-slick-index="0" aria-hidden="false"  tabindex="0">
                            <a href="bangladesh-exhibition.php">
                                <!-- featured-imagebox-post -->
                                <div class="featured-imagebox featured-imagebox-post style1">
                                    <div class="featured-thumbnail"> 
                                        <img class="img-fluid" src="images/exhibition/bangladesh-exibition/0.jpg" alt="" height="100%" width="100%"> 
                                    </div>
                                    <div class="featured-content">
                                        <!-- ttm-box-post-date end -->
                                        <div class="featured-title">
                                            <h3>Bangladesh Exhibition</h3>
                                        </div>
                                    </div>
                                </div>
                                <!-- featured-imagebox-post end -->
                            </a>
                        </div>

                        <div class="col-lg-4 wow fadeInUp animated animated" data-slick-index="0" aria-hidden="false"  tabindex="0">
                            <a href="surat-exhibition.php">
                                <!-- featured-imagebox-post -->
                                <div class="featured-imagebox featured-imagebox-post style1">
                                    <div class="featured-thumbnail"> 
                                        <img class="img-fluid" src="images/exhibition/surat-exibition/0.jpg" alt="" height="100%" width="100%"> 
                                    </div>
                                    <div class="featured-content">
                                        <!-- ttm-box-post-date end -->
                                        <div class="featured-title">
                                            <h3>Surat Exhibition</h3>
                                        </div>
                                    </div>
                                </div>
                                <!-- featured-imagebox-post end -->
                            </a>
                        </div>

                    </div>
                    <!-- row end -->
                </div>
            </section>
            <!--fid-section end-->
            <!--padding_zero-section-->
            <!--padding_zero-section end-->
            <!--padding_top_zero-section-->
            <!--padding_top_zero-section end -->
            <!--testimonial-section end-->
            <!--service-section-->
            <!--service-section end -->
            <!--blog-section-->
            <!--blog-section end-->
            <!--blog-section end-->
        </div>
        <!--site-main end-->
        <!--footer start-->
        <footer class="footer widget-footer ttm-bgcolor-darkgrey ttm-textcolor-white clearfix">
            <div class="second-footer">
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3 widget-area wow fadeInUp animated">
        <div class="widget widget-latest-tweets clearfix">
          <h6 class="">Shree Ganesh Jari Covering Pvt. Ltd.</h6>
          <ul class="widget_contact_wrapper">
            <li><i class="ttm-textcolor-skincolor fa fa-map-marker"></i> <b>Office</b><br/>3013, Central Bazar,<br/>
             Opp. Varachha Police Station,<br/>
              Varachha Main Road,<br/>
              Surat-395006,<br/>
              Gujarat, India </li>
            <li><i class="ttm-textcolor-skincolor fa fa-map-marker"></i> <b>Factory</b><br/>Block No 225, Plot No: 2 to 5,<br/>
             Shree Krishna Industrial Estate,<br/>
              Mota Borsara, Nr.Darbar Hotel,<br/>
              Kim, Surat-394110,<br/>
              Gujarat, India </li>
          </ul>
        </div>
      </div>
      <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3 offset-md-1 widget-area wow fadeInUp animated">
        <div class="widget widget-latest-tweets clearfix">
          <h6 class="">Contact Us</h6>
          <ul class="widget_contact_wrapper">
            <li><i class="ttm-textcolor-skincolor fa fa-phone"></i><a href="tel:918000971500"> +91 80009 71500</a></li>
            <li><i class="ttm-textcolor-skincolor fa fa-whatsapp"></i><a href="tel:919016025691"> +91 99047 71500</a></li>
            <li><i class="ttm-textcolor-skincolor fa fa-envelope-o"></i><a href="mailto:sales@ganeshthread.com"> sales@ganeshthread.com</a></li>
            <!--li><i class="ttm-textcolor-skincolor fa fa fa-map-marker"></i><a href="https://g.page/ganesh-jari-thread?gm" target="_blank">Map & Direction</a></li-->
          </ul>
        </div>
      </div>      
      <div class="col-xs-12  col-sm-6 col-md-6 col-lg-2 widget-area wow fadeInUp animated">
        <div class="widget widget_nav_menu clearfix">
          <h6 class="">Quick Links</h6>
          <ul id="menu-footer-quick-links" class="menu">
            <li><a href="index.php">Home</a></li>
            <li><a href="company-profile.php">About</a></li>
            <li><a href="dealer-network.php"> Dealer Network</a></li>
            <li><a href="photo-gallery.php">Gallery</a></li>
            <li><a href="inquiry.php">Dealership Inquiry</a></li>
            <li><a href="pay.php">Pay Online</a></li>
			<li><a href="contact-us.php">Contact Us</a></li>
            <li><a href="blog.php">Blog</a></li>
          </ul>
        </div>
      </div>
      <div class="col-xs-12 col-sm-6 col-md-6 col-lg-2 widget-area wow fadeInUp animated">
        <div class="widget widget_nav_menu clearfix">
          <h6 class="">Our Products</h6>
          <ul id="menu-footer-quick-links" class="menu">
            <li><a href="flora-zari.php">Flora Zari (Jari Kasab)</a></li>
            <li><a href="polyester-yarn.php">Polyester Yarn </a></li>
            <li><a href="cotton-yarn.php">Cotton Yarn </a></li>
            <li><a href="metallic-film.php">Metallic Film </a></li>
            <li><a href="viscose-yarn.php">Viscose Yarn </a></li>
            <li><a href="embroidery-thread.php">Embroidery  Thread</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="bottom-footer-text copyright">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 text-center">
        <div class="widget widget_social clearfix">
          <div class="social-icons">
            <ul class="social-icons list-inline">
              <li><a class="tooltip-top" href="https://www.facebook.com/ganeshjaricovering" target="_blank" rel="noopener" aria-label="facebook" data-tooltip="Facebook"><i class="fa fa-facebook"></i></a></li>
              <li><a class="tooltip-top" href="https://www.instagram.com/shreeganeshjaricovering/" target="_blank" rel="noopener" aria-label="instagram" data-tooltip="Instagram"><i class="fa fa-instagram"></i></a></li>
              <li><a class="tooltip-top" href="https://twitter.com/ShreeJari?s=09" target="_blank" rel="noopener" aria-label="twitter" data-tooltip="Twitter"><i class="fa fa-twitter"></i></a></li>
              <li><a class="tooltip-top" href="https://in.pinterest.com/ganeshjari2015/" target="_blank" rel="noopener" aria-label="pinterest" data-tooltip="Pinterest"><i class="fa fa-pinterest"></i></a></li>
              <li><a class="tooltip-top" href="https://www.linkedin.com/in/ganesh-jari-thread-87473919b/" target="_blank" rel="noopener" aria-label="linkedin" data-tooltip="Linkedin"><i class="fa fa-linkedin"></i></a></li>
              <li><a class="tooltip-top" href="https://www.youtube.com/channel/UCrhCuUlYXh9meL4NEGJbDUQ?view_as=subscriber" target="_blank" rel="noopener" aria-label="youtube" data-tooltip="Youtube"><i class="fa fa-youtube"></i></a></li>
              <li><a class="tooltip-top" href="https://t.me/Ganeshjari14" target="_blank" rel="noopener" aria-label="telegram" data-tooltip="Telegram"><i class="fa fa-telegram" aria-hidden="true"></i> </a></li>
              <li><a class="tooltip-top" href="https://www.google.com/maps/place//data=!4m2!3m1!1s0x3be047456bfe347d:0xb9d32c48cedd3813?source=g.page.m" target="_blank" rel="noopener" aria-label="Map and Direction" data-tooltip="Map and Direction"><i class="fa fa-map-marker" aria-hidden="true"></i> </a></li>
            </ul>
          </div>
        </div>
        <br/>
        <div class="text-center"> <span class="cpy-text">Copyright &copy; 2021 <a href="#" class="ttm-textcolor-skincolor font-weight-500">Shree Ganesh Jari Covering</a> All rights reserved.</span> </div>
      </div>
    </div>
  </div>
</div>
        </footer>
        <!--footer end-->
        <!--back-to-top start-->
        <a id="totop" href="#top"> <i class="fa fa-angle-up"></i> </a>
        <!--back-to-top end-->
    </div>
    <!-- page end -->
    <!-- Javascript -->
        <!-- Javascript end-->
    <style type="text/css">
    .content {
        height: 295px;
        width: 361px;
        text-align: center;
    }

    .content .content-overlay {
        width: 100% !important;
    }

    .content img {
        height: 100%;
        width: auto;
        /* background-color: red;*/
    }
    </style>
</body>

</html>